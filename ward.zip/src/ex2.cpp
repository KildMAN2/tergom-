#include <fstream>
#include <iomanip>
#include <map>
#include <vector>
#include <algorithm>
#include "pin.H"

using std::ofstream;
using std::map;
using std::vector;
using std::pair;
using std::hex;
using std::dec;
using std::sort;

struct BBLInfo {
    UINT64 execCount{0};
    UINT64 takenCount{0};
    UINT64 fallthroughCount{0};
    map<ADDRINT, UINT64> indirectTargets;
};

static map<ADDRINT, BBLInfo> bblData;
static PIN_LOCK dataLock;

VOID countEntry(ADDRINT addr) {
    PIN_GetLock(&dataLock, 1);
    bblData[addr].execCount++;
    PIN_ReleaseLock(&dataLock);
}

VOID countCond(ADDRINT addr, BOOL taken) {
    PIN_GetLock(&dataLock, 2);
    if (taken)
        bblData[addr].takenCount++;
    else
        bblData[addr].fallthroughCount++;
    PIN_ReleaseLock(&dataLock);
}

VOID countIndirect(ADDRINT addr, ADDRINT target) {
    PIN_GetLock(&dataLock, 3);
    bblData[addr].indirectTargets[target]++;
    PIN_ReleaseLock(&dataLock);
}

VOID instrumentTrace(TRACE trace, VOID*) {
    for (BBL bbl = TRACE_BblHead(trace); BBL_Valid(bbl); bbl = BBL_Next(bbl)) {
        ADDRINT bblAddr = BBL_Address(bbl);
        BBL_InsertCall(bbl, IPOINT_ANYWHERE, AFUNPTR(countEntry), IARG_ADDRINT, bblAddr, IARG_END);

        INS tail = BBL_InsTail(bbl);
        if (INS_IsBranch(tail) && INS_HasFallThrough(tail)) {
            INS_InsertCall(tail, IPOINT_TAKEN_BRANCH, AFUNPTR(countCond),
                           IARG_ADDRINT, bblAddr, IARG_BOOL, TRUE, IARG_END);
            INS_InsertCall(tail, IPOINT_AFTER, AFUNPTR(countCond),
                           IARG_ADDRINT, bblAddr, IARG_BOOL, FALSE, IARG_END);
        }
        else if (INS_IsIndirectControlFlow(tail)) {
            INS_InsertCall(tail, IPOINT_BEFORE, AFUNPTR(countIndirect),
                           IARG_ADDRINT, bblAddr, IARG_BRANCH_TARGET_ADDR, IARG_END);
        }
    }
}

VOID finalize(INT32, VOID*) {
    vector<pair<ADDRINT, BBLInfo>> entries(bblData.begin(), bblData.end());
    sort(entries.begin(), entries.end(),
         [](auto &a, auto &b) { return a.second.execCount > b.second.execCount; });

    ofstream out("edge-profile.csv");
    for (auto &e : entries) {
        const auto &info = e.second;
        if (info.execCount == 0) continue;
        out << hex << "0x" << e.first << dec << ", " << info.execCount;

        if (info.takenCount + info.fallthroughCount > 0) {
            out << ", " << info.takenCount << ", " << info.fallthroughCount;
        } else {
            out << ", , ";
        }

        if (!info.indirectTargets.empty()) {
            vector<pair<ADDRINT, UINT64>> targets(info.indirectTargets.begin(),
                                                   info.indirectTargets.end());
            sort(targets.begin(), targets.end(),
                 [](auto &a, auto &b) { return a.second > b.second; });
            int limit = std::min((size_t)10, targets.size());
            for (int i = 0; i < limit; ++i) {
                out << ", " << hex << "0x" << targets[i].first << dec
                    << ", " << targets[i].second;
            }
        }
        out << "\n";
    }
}

int main(int argc, char *argv[]) {
    if (PIN_Init(argc, argv)) {
        return 1;
    }
    PIN_InitLock(&dataLock);
    TRACE_AddInstrumentFunction(instrumentTrace, nullptr);
    PIN_AddFiniFunction(finalize, nullptr);
    PIN_StartProgram();
    return 0;
}

