Sari Mansour
322449539

Raneem Iraqi
212904015

in order to compiel my pintool, change your working directory to the root path of the installed pintool folder, copy the files in the src folder to the pin tool's root folder, and then run the following commands:

1) cp ex2.cpp jumpmix.cpp makefile makefile.rules source/tools/MyPinTool/
2) cd source/tools/MyPinTool/
3) make ex2.test

now you will have the compiled ex1.so file in the obj-intel64 that was created in the current WD. ($RootPintool/source/tools/MyPinTool/obj-intel64).
