#include "pin.H"
#include <unordered_map>
#include <vector>
#include <algorithm>
#include <fstream>
#include <iostream> // בשביל cerr


using namespace std;

/* ====== Configuration ====== */
constexpr const char* OUTPUT_FILE = "edge-profile.csv";
constexpr int MAX_TARGETS = 10;

/* ====== Data Structures ====== */
struct BBLData {
    UINT64 exec_count = 0;
    UINT64 taken = 0;
    UINT64 fallthrough = 0;
    unordered_map<ADDRINT, UINT64> targets;
};

unordered_map<ADDRINT, BBLData> profile;

/* ====== Instrumentation ====== */
VOID PIN_FAST_ANALYSIS_CALL CountExec(ADDRINT addr) {
    profile[addr].exec_count++;
}

VOID PIN_FAST_ANALYSIS_CALL CountBranch(ADDRINT addr, BOOL taken) {
    taken ? profile[addr].taken++ : profile[addr].fallthrough++;
}

VOID PIN_FAST_ANALYSIS_CALL CountIndirect(ADDRINT addr, ADDRINT target) {
    profile[addr].targets[target]++;
}

VOID InstrumentBBL(BBL bbl) {
    const ADDRINT addr = BBL_Address(bbl);
    BBL_InsertCall(bbl, IPOINT_ANYWHERE, AFUNPTR(CountExec),
                  IARG_FAST_ANALYSIS_CALL,
                  IARG_ADDRINT, addr,
                  IARG_END);

    INS tail = BBL_InsTail(bbl);
    if (INS_IsDirectControlFlow(tail) && INS_HasFallThrough(tail)) {
    INS_InsertCall(tail, IPOINT_BEFORE, AFUNPTR(CountBranch),
                  IARG_FAST_ANALYSIS_CALL,
                  IARG_ADDRINT, addr,
                  IARG_BRANCH_TAKEN,
                  IARG_END);
}
else if (INS_IsIndirectControlFlow(tail)) {
    INS_InsertCall(tail, IPOINT_BEFORE, AFUNPTR(CountIndirect),
                  IARG_FAST_ANALYSIS_CALL,
                  IARG_ADDRINT, addr,
                  IARG_BRANCH_TARGET_ADDR,
                  IARG_END);
}

}

/* ====== Output ====== */
VOID SaveResults(INT32, VOID*) {
    ofstream out(OUTPUT_FILE);
    vector<pair<ADDRINT, BBLData>> sorted(profile.begin(), profile.end());
    
    sort(sorted.begin(), sorted.end(), [](const auto& a, const auto& b) {
        return a.second.exec_count > b.second.exec_count;
    });
for (const auto& entry : sorted) {
    const ADDRINT addr = entry.first;
    const BBLData& data = entry.second;

    if (data.exec_count == 0) continue;

    out << hex << "0x" << addr << dec 
        << "," << data.exec_count;

    if (data.taken + data.fallthrough > 0) {
        out << "," << data.taken << "," << data.fallthrough;
    } else {
        out << ",,";
    }

    if (!data.targets.empty()) {
        vector<pair<ADDRINT, UINT64>> targets(data.targets.begin(), data.targets.end());
        sort(targets.begin(), targets.end(), [](const auto& a, const auto& b) {
            return a.second > b.second;
        });

        int cnt = 0;
        for (const auto& targetEntry : targets) {
            ADDRINT target = targetEntry.first;
            UINT64 count = targetEntry.second;
            if (cnt++ >= MAX_TARGETS) break;
            out << ",0x" << hex << target << dec << "," << count;
        }
    }
    out << "\n";
}

}

/* ====== Main ====== */
int main(int argc, char* argv[]) {
    PIN_InitSymbols();
    if (PIN_Init(argc, argv)) {
        cerr << "Usage: pin -t ex2.so -- <program>\n";
        return 1;
    }

    TRACE_AddInstrumentFunction([](TRACE trace, VOID*) {
        for (BBL bbl = TRACE_BblHead(trace); BBL_Valid(bbl); bbl = BBL_Next(bbl)) {
            InstrumentBBL(bbl);
        }
    }, nullptr);

    PIN_AddFiniFunction(SaveResults, nullptr);
    PIN_StartProgram();
    return 0;
}
