#include <fstream>
#include <iostream>
#include <map>
#include <vector>
#include <algorithm>
#include "pin.H"

using namespace std;

// Output file for profiling results
ofstream outFile;

// Structure to hold information about each basic block
struct BasicBlockInfo {
    UINT64 executionCount = 0;
    UINT64 branchTakenCount = 0;
    UINT64 branchFallthroughCount = 0;
    map<ADDRINT, UINT64> indirectBranchTargets;
};

// Map to store basic block information indexed by address
map<ADDRINT, BasicBlockInfo> basicBlockMap;

// Function to increment the execution count of a basic block
VOID RecordBasicBlockExecution(ADDRINT blockAddress) {
    basicBlockMap[blockAddress].executionCount++;
}

// Function to record the outcome of a conditional branch
VOID RecordConditionalBranch(ADDRINT blockAddress, BOOL branchTaken) {
    if (branchTaken) {
        basicBlockMap[blockAddress].branchTakenCount++;
    } else {
        basicBlockMap[blockAddress].branchFallthroughCount++;
    }
}

// Function to record the target of an indirect branch
VOID RecordIndirectBranch(ADDRINT blockAddress, ADDRINT targetAddress, BOOL branchTaken) {
    if (branchTaken) {
        basicBlockMap[blockAddress].indirectBranchTargets[targetAddress]++;
    }
}

// Instrumentation function to analyze basic blocks within a trace
VOID AnalyzeTrace(TRACE trace, VOID* v) {
    for (BBL block = TRACE_BblHead(trace); BBL_Valid(block); block = BBL_Next(block)) {
        ADDRINT blockAddress = BBL_Address(block);

        BBL_InsertCall(block, IPOINT_ANYWHERE, (AFUNPTR)RecordBasicBlockExecution, IARG_ADDRINT, blockAddress, IARG_END);

        INS lastInstruction = BBL_InsTail(block);

        if (INS_IsBranch(lastInstruction) && INS_HasFallThrough(lastInstruction) && !INS_IsIndirectControlFlow(lastInstruction)) {
            INS_InsertCall(lastInstruction, IPOINT_BEFORE, (AFUNPTR)RecordConditionalBranch, IARG_ADDRINT, blockAddress, IARG_BRANCH_TAKEN, IARG_END);
        }

        if (INS_IsIndirectControlFlow(lastInstruction)) {
            INS_InsertCall(lastInstruction, IPOINT_BEFORE, (AFUNPTR)RecordIndirectBranch, IARG_ADDRINT, blockAddress, IARG_BRANCH_TARGET_ADDR, IARG_BRANCH_TAKEN, IARG_END);
        }
    }
}

// Comparator function for sorting basic blocks by execution count
bool SortByExecutionCount(const pair<ADDRINT, BasicBlockInfo>& a, const pair<ADDRINT, BasicBlockInfo>& b) {
    return a.second.executionCount > b.second.executionCount;
}

// Finalization function to output profiling results to a file
VOID OutputResults(INT32 code, VOID* v) {
    vector<pair<ADDRINT, BasicBlockInfo>> sortedBlocks(basicBlockMap.begin(), basicBlockMap.end());
    sort(sortedBlocks.begin(), sortedBlocks.end(), SortByExecutionCount);

    outFile.open("edge-profile.csv");

    for (const auto& entry : sortedBlocks) {
        ADDRINT address = entry.first;
        const BasicBlockInfo& info = entry.second;

        if (info.executionCount == 0) continue;

        outFile << hex << "0x" << address << dec << ", " << info.executionCount;

        if (info.branchTakenCount + info.branchFallthroughCount > 0) {
            outFile << ", " << info.branchTakenCount << ", " << info.branchFallthroughCount;
        } else {
            outFile << ", , ";
        }

        if (!info.indirectBranchTargets.empty() && info.branchTakenCount == 0 && info.branchFallthroughCount == 0) {
            vector<pair<ADDRINT, UINT64>> targets(info.indirectBranchTargets.begin(), info.indirectBranchTargets.end());
            sort(targets.begin(), targets.end(), [](const auto& a, const auto& b) {
                return a.second > b.second;
            });
            int count = 0;
            for (const auto& target : targets) {
                if (target.second == 0) continue;
                if (count >= 10) break;
                outFile << ", 0x" << hex << target.first << dec << ", " << target.second;
                count++;
            }
        }

        outFile << endl;
    }

    outFile.close();
}

// Main function to initialize and start the PIN tool
int main(int argc, char* argv[]) {
    PIN_InitSymbols();
    if (PIN_Init(argc, argv)) {
        cerr << "Usage: pin -t <toolname>.so -- <program>" << endl;
        return -1;
    }

    TRACE_AddInstrumentFunction(AnalyzeTrace, nullptr);
    PIN_AddFiniFunction(OutputResults, nullptr);

    PIN_StartProgram();
    return 0;
}
