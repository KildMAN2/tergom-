
#include "pin.H"
#include <string.h>
#include <iostream>
#include <fstream>
#include <list>

using namespace std ;
class RTN_Node{
public:
    RTN rtn;
    string RTName;
    ADDRINT RTNAdd;
    string ImgName;
    ADDRINT ImgAdd;
    UINT64  rtnCount;
    UINT64  cnt;
    class RTN_Node* next;
    RTN_Node()=default;
  //  RTN_Node(RTN rtn,const string& name,ADDRINT add,const string& img_name,ADDRINT img_add, UINT64 cnt=0, UINT64 rtnCount = 0):
  //  rtn(rtn),RTName(name),RTNAdd(add),ImgName(img_name),ImgAdd(img_add),cnt(cnt), rtnCount(rtnCount){};
  /*  RTN_Node (const RTN_Node& node){
        this->rtn = node.rtn;
        this->cnt = node.cnt;
        this->RTNAdd = node.RTNAdd;
        this->RTName = node.RTName;
        this->ImgAdd = node.ImgAdd;
        this->ImgName = node.ImgName;
        this->rtnCount = node.rtnCount;
    }; */
    ~RTN_Node() = default;
} ;

std::list<RTN_Node*> RTN_List;

void doCount(UINT64* r){
    (*r)++;
}


RTN_Node* RtnList = 0;

bool comp(RTN_Node* r1, RTN_Node* r2)
{
    return (r1->cnt > r2->cnt);
}
/*
RTN_Node* find(RTN rtn){
    for (list<RTN_Node*>::iterator it = RTN_List.begin(); it != RTN_List.end() ; ++it){
        if ( rtn==(*it)->rtn )
            return *it;
    }
    return NULL;
}
*/

void Routine(RTN rtn, void* v){
    RTN_Node* rc = new RTN_Node;
    rc->RTName = RTN_Name(rtn);
    rc->ImgName = IMG_Name(IMG_FindByAddress(RTN_Address(rtn)));
    rc->RTNAdd = RTN_Address(rtn);
    rc->ImgAdd = IMG_LowAddress(IMG_FindByAddress(RTN_Address(rtn)));
    rc->cnt = 0;
    rc->rtnCount =0;
    rc->next = RtnList;
    RtnList = rc;
    RTN_Open(rtn);
    //RTN_Node* tmp_node = new RTN_Node;
    RTN_List.push_back(rc);
    RTN_InsertCall(rtn, IPOINT_BEFORE, (AFUNPTR) doCount, IARG_PTR, &(rc->rtnCount), IARG_END);

    for( INS ins = RTN_InsHead(rtn); INS_Valid(ins); ins = INS_Next(ins))
    {
        INS_InsertCall(ins, IPOINT_BEFORE, (AFUNPTR) doCount, IARG_PTR, &(rc->cnt), IARG_END);
    }
    RTN_Close(rtn);
}



void Fini(int RTN_code, void* v){

    RTN_List.sort(comp);
    std::ofstream outF;
    outF.open("rtn-output.csv");


    for (std::list<RTN_Node*>::iterator it = RTN_List.begin(); it != RTN_List.end() ; ++it){
        if((*it)->rtnCount > 0) {
            outF << (*it)->ImgName << "," << "0x" << hex
                 << (*it)->ImgAdd << "," << (*it)->RTName << "," << "0x" << hex
                 << (*it)->RTNAdd << "," << dec
                 << (*it)->cnt << "," << (*it)->rtnCount << std::endl;
        }

    }
    outF.close();
}




int main(int argc, char * argv[]) {
    PIN_InitSymbols();
    PIN_Init(argc,argv);
    RTN_AddInstrumentFunction(Routine,0);

    PIN_AddFiniFunction(Fini,0);
    PIN_StartProgram();
    return 0;
}
