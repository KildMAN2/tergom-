Name: Bashar Mousa
ID:   323016402

>Compilation Instructions:
	change directory to <pindir>/source/tools/SimpleExamples
	run the following in command line -> $ make ex1.test
	a new directory will be created ./obj-intel64/ containing ex1.so file

>run the tool:
	run the following command -> $ <pindir>/pin -t ex1.so -- <input file>
	results will be found in a new file "rtn-output.csv"