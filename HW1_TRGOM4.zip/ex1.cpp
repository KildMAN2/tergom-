#include <iostream>
#include "pin.H"
#include <string.h>
#include <fstream>
#include <list>


using namespace std;
class RTNode {
public:
    RTN rtn;
    string RTName;
    ADDRINT RTNAdd;
    string  ImgName;
    ADDRINT ImgAdd;
    UINT64  RtnCount;
    UINT64 Count;
    class RTNode * next;

    RTNode()= default;
    ~RTNode() = default;
};
std ::list <RTNode *> RTN_List;
void Do_Count(UINT64 * r) {
    (*r)++;
}
RTNode * RtnList = nullptr ;
bool comp(RTNode * r1 , RTNode * r2) {
    return (r1->Count , r2->Count);
}
void Routine(RTN rtn , void *v) {
    RTNode * RtnCurrent = new RTNode;
    RtnCurrent->RTName = RTN_Name(rtn);
    RtnCurrent->ImgName =IMG_Name(IMG_FindByAddress(RTN_Address(rtn)));
    RtnCurrent->RTNAdd = RTN_Address(rtn);
    RtnCurrent->ImgAdd = IMG_LowAddress(IMG_FindByAddress(RTN_Address(rtn)));
    RtnCurrent->Count = 0 ;
    RtnCurrent->RtnCount = 0;
    RtnCurrent->next = RtnList;
    RtnList = RtnCurrent;
    RTN_Open(rtn);
    RTN_List.push_back(RtnCurrent);
    RTN_InsertCall(rtn, IPOINT_BEFORE, (AFUNPTR) Do_Count, IARG_PTR, &(RtnCurrent->RtnCount), IARG_END);

    for( INS ins = RTN_InsHead(rtn); INS_Valid(ins); ins = INS_Next(ins))
    {
        INS_InsertCall(ins, IPOINT_BEFORE, (AFUNPTR) Do_Count, IARG_PTR, &(RtnCurrent->Count), IARG_END);
    }
    RTN_Close(rtn);
}
void Fini(int RTN_Code,void *v) {
    RTN_List.sort(comp);
    std::ofstream outF;
    outF.open("rtn-output.csv");


    for (std::list<RTNode*>::iterator it = RTN_List.begin(); it != RTN_List.end() ; ++it){
        if((*it)->RtnCount > 0) {
            outF << (*it)->ImgName << "," << "0x" << hex
                 << (*it)->ImgAdd << "," << (*it)->RTName << "," << "0x" << hex
                 << (*it)->RTNAdd << "," << dec
                 << (*it)->Count << "," << (*it)->RtnCount << std::endl;
        }

    }
    outF.close();
}

int main(int argc, char * argv[]) {
    PIN_InitSymbols();
    PIN_Init(argc,argv);
    RTN_AddInstrumentFunction(Routine,0);

    PIN_AddFiniFunction(Fini,0);
    PIN_StartProgram();
    return 0;
}

