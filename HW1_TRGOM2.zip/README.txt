Name: Sari Mansour
ID:   322449539

>Compilation Instructions:
    check if you downloaded Intel pin package
	change directory to <pindir>/source/tools/SimpleExamples
	add ex1.cpp there
	run the following in command line -> $ make ex1.test
	a new directory will be created ./obj-intel64/ containing ex1.so file

>run the tool:
    check the pdf there are more instructions
	run the following command -> $ <pindir>/pin -t ex1.so -- <input file>
	results will be found in a new file "rtn-output.csv"