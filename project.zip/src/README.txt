Project submission README (template)

1) Team
- Names: <Name1>, <Name2>
- IDs: <ID1>, <ID2>

2) Build
- Linux:
  make project.test
  # or per your environment: make obj-intel64/project.so
- Windows:
  Build obj-intel64\project.dll using Pin sample makefiles or VS with Pin include/lib paths.

3) How to run
- Baseline sanity (no commit):
  PIN_NO_TC_COMMIT=1 $PIN_ROOT/pin -t obj-intel64/project.so -- ./cc1 expr.i
- Create TC2 after 4s profiling:
  $PIN_ROOT/pin -t obj-intel64/project.so -create_tc2 1 -prof_time 4 -- ./cc1 expr.i
- With guarded devirtualization (safe defaults):
  $PIN_ROOT/pin -t obj-intel64/project.so -no_tc_commit 0 -create_tc2 1 -prof_time 4 -devirt_indir 1 -devirt_only_terminators 1 -- ./cc1 expr.i

4) Thresholds and rationale
- indir_hot_pct = 80: A target must account for >=80% of executions at its site to be considered hot.
- indir_min_count = 100: Require at least 100 executions to avoid noise from cold sites.
- Rationale: balances aggressiveness vs. safety for guarded devirtualization, tuned for cc1-style workloads.

5) Notes
- Overhead target: <=15% beyond native (excluding TC creation). Measure with: time ./cc1 expr.i and subtract the printed "create_tc took:" time from the tool run.
- Extra knobs (optional): -commit_limit for staged commits; -use_killed_regs to toggle fast-path counters; -prof_indir to toggle target profiling.
