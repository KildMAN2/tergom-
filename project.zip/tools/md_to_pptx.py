import sys
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN

# Simple Markdown-to-PowerPoint converter tailored to our deck style
# Supports: headings (#, ##), code blocks (```), bullet lists, notes sections (Notes:)

def add_slide(prs, title, bullets=None, code=None, notes=None):
    slide_layout = prs.slide_layouts[1]  # Title and Content
    slide = prs.slides.add_slide(slide_layout)
    slide.shapes.title.text = title

    body = slide.shapes.placeholders[1].text_frame
    body.clear()

    if bullets:
        for i, line in enumerate(bullets):
            if i == 0:
                p = body.paragraphs[0]
            else:
                p = body.add_paragraph()
            p.text = line
            p.level = 0
            p.font.size = Pt(20)

    if code:
        # Put code as a single preformatted textbox below bullets
        tb = slide.shapes.add_textbox(Inches(0.5), Inches(4.0), Inches(9.0), Inches(3.0))
        tf = tb.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.text = code
        p.font.name = 'Consolas'
        p.font.size = Pt(14)

    if notes:
        # Add as slide notes
        notes_slide = slide.notes_slide
        notes_tf = notes_slide.notes_text_frame
        notes_tf.text = notes


def parse_md(md_text):
    lines = md_text.splitlines()
    slides = []
    in_code = False
    code_buf = []
    cur_title = None
    cur_bullets = []
    cur_notes = None

    def flush():
        nonlocal cur_title, cur_bullets, code_buf, cur_notes
        if cur_title:
            code_text = "\n".join(code_buf).strip() if code_buf else None
            slides.append((cur_title, [b for b in cur_bullets if b.strip()], code_text or None, cur_notes))
        cur_title = None
        cur_bullets = []
        code_buf = []
        cur_notes = None

    for raw in lines:
        line = raw.rstrip('\n')
        if line.strip().startswith('```'):
            in_code = not in_code
            if not in_code:
                # End of code block
                pass
            continue
        if in_code:
            code_buf.append(line)
            continue
        if line.startswith('---') and not cur_title:
            # slide delimiter at top is ignored (Marp frontmatter)
            continue
        if line.startswith('# '):
            flush()
            cur_title = line[2:].strip()
            continue
        if line.startswith('## '):
            flush()
            cur_title = line[3:].strip()
            continue
        if line.strip().startswith('Notes:'):
            cur_notes = line.split('Notes:',1)[1].strip()
            continue
        # bullets
        if line.strip().startswith('- '):
            cur_bullets.append(line.strip()[2:])
            continue
        # blank line between bullets is ok
        if not line.strip():
            continue
        # Fallback: treat as bullet
        cur_bullets.append(line.strip())

    flush()
    return slides


def md_to_pptx(md_path, pptx_path):
    with open(md_path, 'r', encoding='utf-8') as f:
        md_text = f.read()
    prs = Presentation()
    # remove default title slide by starting with a blank presentation and adding our own slides
    prs.slides._sldIdLst[:] = []

    for title, bullets, code, notes in parse_md(md_text):
        add_slide(prs, title, bullets, code, notes)

    prs.save(pptx_path)


if __name__ == '__main__':
    md_path = sys.argv[1] if len(sys.argv) > 1 else 'docs/presentation.md'
    pptx_path = sys.argv[2] if len(sys.argv) > 2 else 'docs/presentation.pptx'
    md_to_pptx(md_path, pptx_path)
