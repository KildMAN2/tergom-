# Benchmarks an app across modes (NATIVE, TC2_NO_COMMIT, TC2_COMMIT, TC2_DEVIRT)
# and prints a table similar to the sample screenshot.
param(
  [string]$PinExe,           # Path to pin executable (e.g., C:\pin\pin.exe)
  [string]$ToolPath,         # Path to the built tool (DLL or SO depending on platform)
  [string]$App,              # Path to target application (e.g., C:\Program Files\bzip2\bzip2.exe)
  [string[]]$AppArgs = @(),  # Arguments for the application
  [int]$Runs = 5,            # Number of runs per mode
  [switch]$UseDevirt = $true # Whether to include TC2_DEVIRT mode
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function New-TempFile {
  return [System.IO.Path]::Combine([System.IO.Path]::GetTempPath(), [System.IO.Path]::GetRandomFileName())
}

function Get-Median([double[]]$vals) {
  if (-not $vals -or $vals.Count -eq 0) { return 0.0 }
  $sorted = $vals | Sort-Object
  $n = $sorted.Count
  if ($n % 2 -eq 1) { return [double]$sorted[[int]([math]::Floor($n/2))] }
  else { return ([double]$sorted[$n/2 - 1] + [double]$sorted[$n/2]) / 2.0 }
}

function Run-OnceNative([string]$app, [string[]]$args) {
  $sw = [System.Diagnostics.Stopwatch]::StartNew()
  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName = $app
  $psi.Arguments = [string]::Join(' ', ($args | ForEach-Object { $_ }))
  $psi.UseShellExecute = $false
  $psi.RedirectStandardError = $true
  $psi.RedirectStandardOutput = $true
  $p = [System.Diagnostics.Process]::Start($psi)
  $p.WaitForExit()
  $sw.Stop()
  return [pscustomobject]@{
    dur_s        = [math]::Round($sw.Elapsed.TotalSeconds, 3)
    create_tc_s  = 0.0
    post_user_s  = [math]::Round($sw.Elapsed.TotalSeconds, 3)
    stderr       = $p.StandardError.ReadToEnd()
    stdout       = $p.StandardOutput.ReadToEnd()
  }
}

function Run-OncePin([string]$pin, [string]$tool, [string]$app, [string[]]$args, [string[]]$knobs, [bool]$noCommit) {
  $errPath = New-TempFile
  $outPath = New-TempFile
  try {
    if ($noCommit) { $env:PIN_NO_TC_COMMIT = '1' } else { $env:PIN_NO_TC_COMMIT = $null }

    $pinArgs = @('-t', $tool) + $knobs + @('--', $app) + $args

    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $pin
    $psi.Arguments = [string]::Join(' ', ($pinArgs | ForEach-Object { $_ }))
    $psi.UseShellExecute = $false
    $psi.RedirectStandardError = $true
    $psi.RedirectStandardOutput = $true
    $p = [System.Diagnostics.Process]::Start($psi)
    $stdOut = $p.StandardOutput.ReadToEnd()
    $stdErr = $p.StandardError.ReadToEnd()
    $p.WaitForExit()
    $sw.Stop()

    # Parse 'create_tc took: X seconds' from stderr if present
    $create = 0.0
    $m = [regex]::Match($stdErr, 'create_tc took:\s*([0-9.]+)\s*seconds')
    if ($m.Success) { $create = [double]::Parse($m.Groups[1].Value) }
    $dur = [math]::Round($sw.Elapsed.TotalSeconds, 3)
    $post = [math]::Round([math]::Max(0.0, $dur - $create), 3)

    return [pscustomobject]@{
      dur_s        = $dur
      create_tc_s  = [math]::Round($create, 3)
      post_user_s  = $post
      stderr       = $stdErr
      stdout       = $stdOut
    }
  } finally {
    $env:PIN_NO_TC_COMMIT = $null
    Remove-Item -ErrorAction SilentlyContinue $errPath, $outPath
  }
}

if (-not (Test-Path $App)) { throw "App not found: $App" }
if ($PinExe -and -not (Test-Path $PinExe)) { throw "Pin not found: $PinExe" }
if ($PinExe -and -not (Test-Path $ToolPath)) { throw "Tool not found: $ToolPath" }

$modes = @(
  @{ name = 'NATIVE';       pin = $false; knobs = @();                noCommit = $false },
  @{ name = 'TC2_NO_COMMIT'; pin = $true;  knobs = @('-create_tc2', '1'); noCommit = $true  },
  @{ name = 'TC2_COMMIT';    pin = $true;  knobs = @('-create_tc2', '1'); noCommit = $false }
)
if ($UseDevirt) {
  $modes += @{ name = 'TC2_DEVIRT'; pin = $true; knobs = @('-create_tc2', '1', '-devirt_indir', '1'); noCommit = $false }
}

# Storage for results per mode
$results = @{}
foreach ($m in $modes) { $results[$m.name] = @() }

Write-Host "== Benchmark =="
Write-Host ("App: {0} {1}" -f $App, ([string]::Join(' ', $AppArgs)))
Write-Host ("Runs: {0}" -f $Runs)
Write-Host "----------------------------------------------"

for ($i=1; $i -le $Runs; $i++) {
  foreach ($m in $modes) {
    if (-not $m.pin) {
      $r = Run-OnceNative -app $App -args $AppArgs
    } else {
      $r = Run-OncePin -pin $PinExe -tool $ToolPath -app $App -args $AppArgs -knobs $m.knobs -noCommit $m.noCommit
    }
    $results[$m.name] += $r
  }
}

function Summarize($name) {
  $rs = $results[$name]
  $dur = Get-Median ($rs | ForEach-Object { $_.dur_s })
  $post = Get-Median ($rs | ForEach-Object { $_.post_user_s })
  $create = Get-Median ($rs | ForEach-Object { $_.create_tc_s })
  return [pscustomobject]@{
    name = $name
    dur_s = $dur
    user_s = $post   # align label with screenshot (post_user_s)
    create_tc_s = $create
    post_user_s = $post
    taskclk_ms = ''
    ctx_sw = ''
    cpu_migr = ''
    page_faults = ''
  }
}

$summary = $modes | ForEach-Object { Summarize $_.name }

# Print table
"mode        dur_s   user_s  create_tc_s  post_user_s  taskclk_ms  ctx_sw  cpu_migr  page_faults"
foreach ($row in $summary) {
  "{0,-11}{1,6:N3}  {2,6:N3}  {3,11:N3}  {4,12:N3}  {5,10}  {6,6}  {7,8}  {8,11}" -f `
    $row.name, $row.dur_s, $row.user_s, $row.create_tc_s, $row.post_user_s, $row.taskclk_ms, $row.ctx_sw, $row.cpu_migr, $row.page_faults
}

# Deltas vs NATIVE
$native = $summary | Where-Object { $_.name -eq 'NATIVE' }
if ($native) {
  ""
  "Comparison vs NATIVE (medians)"
  foreach ($row in $summary) {
    if ($row.name -eq 'NATIVE') { continue }
    $dPost = if ($native.post_user_s -gt 0) { 100.0 * ($row.post_user_s - $native.post_user_s) / $native.post_user_s } else { 0.0 }
    $dDur  = if ($native.dur_s -gt 0) { 100.0 * ($row.dur_s - $native.dur_s) / $native.dur_s } else { 0.0 }
    "{0}  Δpost_user= {1,6:N2}%   Δdur= {2,6:N2}%" -f $row.name, $dPost, $dDur
  }
}

""
Write-Host "Tip: set -UseDevirt:	TC2_DEVIRT adds -devirt_indir 1"
Write-Host "Tip: to reduce commit log noise:	add -quiet_distance 1 to your tool knobs"
