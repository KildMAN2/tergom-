#!/usr/bin/env bash
set -euo pipefail

PIN_EXE=${PIN_EXE:-"${PIN_ROOT:-}/pin"}
TOOL=${TOOL:-"$(dirname "$0")/../obj-intel64/project.so"}
RUNS=${RUNS:-5}
USE_DEVIRT=${USE_DEVIRT:-1}
WARMUP=${WARMUP:-0}
SLIDE=${SLIDE:-0}
BREAK_EVEN=${BREAK_EVEN:-0}
# If set to a filename, append CSV summary (one line per mode)
CSV_OUT=${CSV_OUT:-}

usage() {
  cat <<EOF
Usage: PIN_ROOT=...</path> tools/bench.sh --app /path/to/app -- [args]

Env/vars:
  PIN_EXE     Path to pin executable (default: \$PIN_ROOT/pin)
  TOOL        Path to pintool .so (default: obj-intel64/project.so)
  RUNS        Number of runs per mode (default: 5)
  USE_DEVIRT  Include TC2_DEVIRT mode (default: 1)
  WARMUP      If 1, perform one native + one Pin commit warmup (discarded) (default: 0)
  SLIDE       If 1, minimal output (table + comparisons only) (default: 0)
  BREAK_EVEN  If 1, print create_tc vs post speedup break-even table (default: 0)
  EXTRA_KNOBS Extra pintool knobs appended to all pin runs (quoted string)
  PROF_TIME   If set, append "-prof_time <seconds>" unless provided in EXTRA_KNOBS
  ECHO_TAIL   If 1, print the last ~25 lines of stderr for each Pin mode
  CSV_OUT     If set (path), append CSV rows (mode,dur_s,create_tc_s,post_user_s,taskclk_ms,ctx_sw,cpu_migr,page_faults)

Modes run:
  NATIVE, TC2_NO_COMMIT, TC2_COMMIT, TC2_DEVIRT (optional)

Examples:
  PIN_ROOT=~/pin-3.31 ./tools/bench.sh --app /usr/bin/bzip2 -- -k -f ./input-long.txt
  EXTRA_KNOBS='-quiet_distance 1 -prof_time 4' PIN_ROOT=~/pin-3.31 ./tools/bench.sh --app ./cc1 -- ./expr.i
  PROF_TIME=0 RUNS=5 ./tools/bench.sh --app /usr/bin/bzip2 -- -k -f ./input-long.txt
  ECHO_TAIL=1 RUNS=3 ./tools/bench.sh --app /usr/bin/bzip2 -- -k -f ./input-long.txt
EOF
}

APP=""
ARGS=()
while [[ $# -gt 0 ]]; do
  case "$1" in
    --app) APP="$2"; shift 2;;
    --help|-h) usage; exit 0;;
    --) shift; ARGS=("$@"); break;;
    *) echo "Unknown arg: $1"; usage; exit 1;;
  esac
done

if [[ -z "$APP" ]]; then echo "--app is required"; usage; exit 1; fi
if [[ ! -x "$PIN_EXE" ]]; then echo "pin not found/executable: $PIN_EXE"; exit 1; fi
if [[ ! -f "$TOOL" ]]; then echo "tool not found: $TOOL"; exit 1; fi

# Preflight: if any ARGS look like file paths (don’t start with '-') ensure they exist.
for a in "${ARGS[@]}"; do
  if [[ -n "$a" && "$a" != -* ]]; then
    if [[ ! -e "$a" ]]; then
      echo "Input file not found: $a" >&2
      echo "Hint: if you have input-long.txt.gz, run: gunzip -kf input-long.txt.gz" >&2
      exit 1
    fi
  fi
done

have_perf=0
if command -v perf >/dev/null 2>&1; then have_perf=1; fi

tmpdir="$(mktemp -d)"
cleanup(){ rm -rf "$tmpdir"; }
trap cleanup EXIT

declare -A DUR CREATE POST TASKCLK CTXSW MIGR MINFLT MAJFLT
declare -a MODES=("NATIVE" "TC2_NO_COMMIT" "TC2_COMMIT")
if [[ "$USE_DEVIRT" == "1" ]]; then MODES+=("TC2_DEVIRT"); fi

run_once_native(){
  local tag=$1 idx=$2
  local t0 t1
  t0=$(date +%s%3N)
  "$APP" "${ARGS[@]}" >/dev/null 2>"$tmpdir/${tag}.${idx}.err"
  t1=$(date +%s%3N)
  local dur_ms=$((t1 - t0))
  local dur_s
  dur_s=$(awk -v ms=$dur_ms 'BEGIN{printf "%.3f", ms/1000.0}')
  DUR[$tag]+=" $dur_s"
  CREATE[$tag]+=" 0"
  POST[$tag]+=" $dur_s"
  if [[ $have_perf -eq 1 ]]; then
    read -r taskclk ctx migr minf majf < <(perf stat -x, -e task-clock,context-switches,cpu-migrations,minor-faults,major-faults -- "$APP" "${ARGS[@]}" 1>/dev/null 2>"$tmpdir/p.out"; awk -F, '/task-clock/{print $1} /context-switches/{print $1} /cpu-migrations/{print $1} /minor-faults/{print $1} /major-faults/{print $1}' "$tmpdir/p.out" | xargs)
    TASKCLK[$tag]+=" $taskclk"; CTXSW[$tag]+=" $ctx"; MIGR[$tag]+=" $migr"; MINFLT[$tag]+=" $minf"; MAJFLT[$tag]+=" $majf"
  fi
}

run_once_pin(){
  local tag=$1 idx=$2 no_commit=$3 shift_args=$4
  local err="$tmpdir/${tag}.${idx}.stderr"
  local t0 t1
  local knobs=("-create_tc2" "1")
  if [[ "$tag" == "TC2_DEVIRT" ]]; then knobs+=("-devirt_indir" "1"); fi
  if [[ -n "${EXTRA_KNOBS:-}" ]]; then
    # Split EXTRA_KNOBS string into an array and append
    # shellcheck disable=SC2206
    extra_knobs=( ${EXTRA_KNOBS} )
    knobs+=("${extra_knobs[@]}")
  fi
  # Append -prof_time from PROF_TIME env var if not already in knobs
  if [[ -n "${PROF_TIME:-}" ]]; then
    has_pt=0
    for ((i=0;i<${#knobs[@]};i++)); do
      if [[ "${knobs[$i]}" == "-prof_time" ]]; then has_pt=1; break; fi
    done
    if [[ $has_pt -eq 0 ]]; then knobs+=("-prof_time" "$PROF_TIME"); fi
  fi
  if [[ "$no_commit" == "1" ]]; then export PIN_NO_TC_COMMIT=1; else unset PIN_NO_TC_COMMIT; fi

  t0=$(date +%s%3N)
  "$PIN_EXE" -t "$TOOL" "${knobs[@]}" -- "$APP" "${ARGS[@]}" >/dev/null 2>"$err"
  t1=$(date +%s%3N)
  local dur_ms=$((t1 - t0))
  # Extract numeric seconds from a line like: "create_tc took: 1.234 seconds"
  local create_s
  create_s=$(awk '/create_tc took:/ {for(i=1;i<=NF;i++){if($i ~ /^[0-9]+(\.[0-9]+)?$/){print $i; exit}}}' "$err" | tail -n1)
  if [[ -z "$create_s" ]]; then create_s=0; fi
  if [[ ! "$create_s" =~ ^[0-9]+(\.[0-9]+)?$ ]]; then create_s=0; fi
  local dur_s=$(awk -v ms=$dur_ms 'BEGIN{printf "%.3f", ms/1000.0}')
  local post_s=$(awk -v d=$dur_s -v c=$create_s 'BEGIN{p=d-c; if(p<0) p=0; printf "%.3f", p}')
  DUR[$tag]+=" $dur_s"; CREATE[$tag]+=" $create_s"; POST[$tag]+=" $post_s"

  if [[ $have_perf -eq 1 ]]; then
    read -r taskclk ctx migr minf majf < <(perf stat -x, -e task-clock,context-switches,cpu-migrations,minor-faults,major-faults -- "$PIN_EXE" -t "$TOOL" "${knobs[@]}" -- "$APP" "${ARGS[@]}" 1>/dev/null 2>"$tmpdir/p.out"; awk -F, '/task-clock/{print $1} /context-switches/{print $1} /cpu-migrations/{print $1} /minor-faults/{print $1} /major-faults/{print $1}' "$tmpdir/p.out" | xargs)
    TASKCLK[$tag]+=" $taskclk"; CTXSW[$tag]+=" $ctx"; MIGR[$tag]+=" $migr"; MINFLT[$tag]+=" $minf"; MAJFLT[$tag]+=" $majf"
  fi
}

median(){
  # Portable median: flatten fields -> sort -n -> compute median without gawk asort
  awk '{for(i=1;i<=NF;i++) if($i!="") print $i}' | sort -n | awk '{a[NR]=$1} END{if(NR==0){print 0} else if(NR%2){print a[(NR+1)/2]} else {print (a[NR/2]+a[NR/2+1])/2}}'
}

echo "== Benchmark =="
app_base=$(basename "$APP")
echo "== 4-way benchmark: $app_base =="
[[ $SLIDE -eq 0 ]] && echo "App: $APP ${ARGS[*]}"
[[ $SLIDE -eq 0 ]] && echo "Runs: $RUNS"
# Show profiling window if provided via EXTRA_KNOBS or PROF_TIME
prof_time_disp=""
if [[ -n "${EXTRA_KNOBS:-}" ]]; then
  # shellcheck disable=SC2206
  ek=( ${EXTRA_KNOBS} )
  for ((i=0;i<${#ek[@]};i++)); do
    if [[ "${ek[$i]}" == "-prof_time" && $((i+1)) -lt ${#ek[@]} ]]; then
      prof_time_disp="${ek[$((i+1))]}"; break
    fi
  done
fi
if [[ -z "$prof_time_disp" && -n "${PROF_TIME:-}" ]]; then prof_time_disp="$PROF_TIME"; fi
if [[ -n "$prof_time_disp" ]]; then echo "Prof Time $prof_time_disp seconds"; fi
if [[ $SLIDE -eq 0 ]]; then
  # Indicate perf status so users know why counters may be blank
  if [[ $have_perf -eq 1 ]]; then
    echo "Perf counters: enabled"
  else
    echo "Perf counters: disabled (install 'perf' to populate taskclk/ctxsw/migrations/faults)"
  fi
  echo "----------------------------------------------"
fi

# Optional warmup
if [[ $WARMUP -eq 1 ]]; then
  echo "(warmup)" >&2
  "$APP" "${ARGS[@]}" >/dev/null 2>&1 || true
  # One Pin commit warmup (use TC2_COMMIT style)
  "$PIN_EXE" -t "$TOOL" -create_tc2 1 -- "$APP" "${ARGS[@]}" >/dev/null 2>&1 || true
fi

for ((i=1;i<=RUNS;i++)); do
  run_once_native NATIVE $i
  run_once_pin TC2_NO_COMMIT $i 1 0
  run_once_pin TC2_COMMIT    $i 0 0
  if [[ "$USE_DEVIRT" == "1" ]]; then run_once_pin TC2_DEVIRT $i 0 1; fi
done

printf "%-12s %7s %8s %12s %12s %11s %7s %9s %12s\n" mode dur_s user_s create_tc_s post_user_s taskclk_ms ctx_sw cpu_migr page_faults
sum_faults(){ awk '{s=0; for(i=1;i<=NF;i++) s+=a[i]; print s}' a="$(echo "$1 $2")"; }

native_dur=$(echo ${DUR[NATIVE]:-0} | median)
native_post=$(echo ${POST[NATIVE]:-0} | median)

for mode in "${MODES[@]}"; do
  dur=$(echo ${DUR[$mode]:-0} | median)
  post=$(echo ${POST[$mode]:-0} | median)
  create=$(echo ${CREATE[$mode]:-0} | median)
  if [[ $have_perf -eq 1 ]]; then
    taskms=$(echo ${TASKCLK[$mode]:-0} | median)
    ctx=$(echo ${CTXSW[$mode]:-0} | median)
    migr=$(echo ${MIGR[$mode]:-0} | median)
    minf=$(echo ${MINFLT[$mode]:-0} | median)
    majf=$(echo ${MAJFLT[$mode]:-0} | median)
    pf=$(awk -v a="$minf" -v b="$majf" 'BEGIN{printf "%.0f", a+b}')
  else
    taskms=""; ctx=""; migr=""; pf=""
  fi
  printf "%-12s %7.3f %8.3f %12.3f %12.3f %11s %7s %9s %12s\n" "$mode" "$dur" "$post" "$create" "$post" "$taskms" "$ctx" "$migr" "$pf"
done

# Collect medians into temporary arrays for optional CSV / break-even
declare -A MED_DUR MED_CREATE MED_POST MED_TASK MED_CTX MED_MIGR MED_PF
native_dur=$(echo ${DUR[NATIVE]:-0} | median)
native_post=$(echo ${POST[NATIVE]:-0} | median)

for mode in "${MODES[@]}"; do
  dur=$(echo ${DUR[$mode]:-0} | median)
  post=$(echo ${POST[$mode]:-0} | median)
  create=$(echo ${CREATE[$mode]:-0} | median)
  MED_DUR[$mode]=$dur; MED_POST[$mode]=$post; MED_CREATE[$mode]=$create
  if [[ $have_perf -eq 1 ]]; then
    taskms=$(echo ${TASKCLK[$mode]:-0} | median)
    ctx=$(echo ${CTXSW[$mode]:-0} | median)
    migr=$(echo ${MIGR[$mode]:-0} | median)
    minf=$(echo ${MINFLT[$mode]:-0} | median)
    majf=$(echo ${MAJFLT[$mode]:-0} | median)
    pf=$(awk -v a="$minf" -v b="$majf" 'BEGIN{printf "%.0f", a+b}')
  else
    taskms=""; ctx=""; migr=""; pf=""
  fi
  MED_TASK[$mode]=$taskms; MED_CTX[$mode]=$ctx; MED_MIGR[$mode]=$migr; MED_PF[$mode]=$pf
done

# Re-print table rows (already printed above individually) not needed

echo
echo "Comparison vs NATIVE (medians)"
for mode in "${MODES[@]}"; do
  [[ "$mode" == "NATIVE" ]] && continue
  dur=${MED_DUR[$mode]}
  post=${MED_POST[$mode]}
  dpost=$(awk -v p=$post -v n=$native_post 'BEGIN{if(n==0){print 0}else{printf "%.2f", 100*(p-n)/n}}')
  ddur=$(awk -v d=$dur -v n=$native_dur 'BEGIN{if(n==0){print 0}else{printf "%.2f", 100*(d-n)/n}}')
  printf "%-12s Δpost_user= %6s%%   Δdur= %6s%%\n" "$mode" "$dpost" "$ddur"
done

if [[ $BREAK_EVEN -eq 1 ]]; then
  echo
  echo "Break-even (per-run): need post speedup >= create_tc / native_post"
  printf "%-12s %12s %12s %12s %12s\n" mode create_s native_post_s need_pct achieved_pct
  for mode in "${MODES[@]}"; do
    [[ "$mode" == "NATIVE" ]] && continue
    c=${MED_CREATE[$mode]}; post=${MED_POST[$mode]}
    need=$(awk -v c=$c -v n=$native_post 'BEGIN{if(n==0){print 0}else{printf "%.2f", 100*c/n}}')
    ach=$(awk -v n=$native_post -v p=$post 'BEGIN{if(n==0){print 0}else{printf "%.2f", 100*(n-p)/n}}')
    printf "%-12s %12.3f %12.3f %12s %12s\n" "$mode" "$c" "$native_post" "$need" "$ach"
  done
fi

if [[ -n "$CSV_OUT" ]]; then
  { for mode in "${MODES[@]}"; do
      printf "%s,%s,%s,%s,%s,%s,%s,%s\n" "$mode" "${MED_DUR[$mode]}" "${MED_CREATE[$mode]}" "${MED_POST[$mode]}" "${MED_TASK[$mode]}" "${MED_CTX[$mode]}" "${MED_MIGR[$mode]}" "${MED_PF[$mode]}";
    done; } >> "$CSV_OUT"
fi

if [[ $SLIDE -eq 0 ]]; then
  echo
  echo "Tip: set USE_DEVIRT=0 to skip TC2_DEVIRT"
  echo "Tip: add -quiet_distance 1 to your tool knobs to reduce commit logs"
fi

# Optionally echo stderr tails to inspect commit/devirt summaries
if [[ "${ECHO_TAIL:-0}" == "1" && $SLIDE -eq 0 ]]; then
  echo
  echo "stderr tails (last run for each Pin mode)"
  for mode in "${MODES[@]}"; do
    [[ "$mode" == "NATIVE" ]] && continue
    f="$tmpdir/${mode}.${RUNS}.stderr"
    if [[ -s "$f" ]]; then
      echo "----- $mode stderr tail -----"
      tail -n 25 "$f"
    fi
  done
fi
