# Troubleshooting

## RTN_ReplaceProbed failed
Cause: prolog not safe for probe, or TC far from original (>2GB). Actions:
- Keep going; failures can be benign if enough routines commit.
- Use `-commit_limit N` to stage and isolate.
- Expect to see: “RTN_ReplaceProbed skipped due to >2GB distance …” (guard is working).

## Crash after TC commit
- Verify correctness without commit:
  - `PIN_NO_TC_COMMIT=1 …`
- Then stage commits:
  - `-no_tc_commit 0 -commit_limit 1`
- If it still crashes:
  - `-use_killed_regs 0` to disable fast-path counters.
  - Try without TC2: remove `-create_tc2`.

## No “[TC2 SWITCH] …” log
- Ensure you run with `-create_tc2 1 -no_tc_commit 0`.
- You should see “after write all new instructions to tc2” before commit.

## `-commit_limit` unknown
- Rebuild the tool so the new knob is compiled in:
  - `make clean ; make obj-intel64/project.so`

## Unrecognized `-Wno-dangling-pointer`
- Remove/guard the flag in Pin’s config makefiles (e.g., `source/tools/Config/makefile.default.rules`).
- Quick fix: filter it out of the warnings variable.

## Performance above 15%
- Ensure `-prof_indir 0` and `-use_killed_regs 1`.
- Increase `-prof_time` slightly to improve profile quality for TC2.
- Tune `-indir_hot_pct`/`-indir_min_count` to avoid over-eager devirtualization.
