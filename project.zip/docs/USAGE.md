# Usage and examples

## Linux quickstart
```bash
# Build your pintool per Pin docs, then:
export PIN_ROOT=~/pin-3.31

# Baseline (no commit)
PIN_NO_TC_COMMIT=1 "$PIN_ROOT/pin" -t obj-intel64/project.so -- ./cc1 expr.i

# TC1 (commit to TC)
"$PIN_ROOT/pin" -t obj-intel64/project.so -no_tc_commit 0 -quiet_distance 1 -- ./cc1 expr.i

# TC2 no commit (profile then build TC2, but don’t patch TC→TC2)
PIN_NO_TC_COMMIT=1 "$PIN_ROOT/pin" -t obj-intel64/project.so -create_tc2 1 -quiet_distance 1 -- ./cc1 expr.i

# TC2 commit (one-time switch to TC2)
"$PIN_ROOT/pin" -t obj-intel64/project.so -create_tc2 1 -quiet_distance 1 -- ./cc1 expr.i

# TC2 with selective devirtualization
"$PIN_ROOT/pin" -t obj-intel64/project.so -create_tc2 1 -devirt_indir 1 -indir_min_count 100 -indir_hot_pct 80 \
	-devirt_only_terminators 1 -quiet_distance 1 -- ./cc1 expr.i
```

## Baseline sanity (no commit)
```bash
PIN_NO_TC_COMMIT=1 $PIN_ROOT/pin -t obj-intel64/project.so -- ./cc1 expr.i
```

- PIN_NO_TC_COMMIT=1: Force no commit even if -no_tc_commit 0 is passed (environment override).

## Stage TC commits gradually
```bash
# Commit one routine
$PIN_ROOT/pin -t obj-intel64/project.so -no_tc_commit 0 -commit_limit 1 -- ./cc1 expr.i
# Increase when stable
$PIN_ROOT/pin -t obj-intel64/project.so -no_tc_commit 0 -commit_limit 20 -- ./cc1 expr.i
$PIN_ROOT/pin -t obj-intel64/project.so -no_tc_commit 0 -- ./cc1 expr.i
```

- -no_tc_commit 0: Actually replace routines to run from TC (set 1 to disable commits).
- -commit_limit N: Cap the number of routines committed (0 = all). Use small N to isolate issues, then raise.

## Enable TC2 + guarded devirtualization
```bash
$PIN_ROOT/pin -t obj-intel64/project.so -no_tc_commit 0 -create_tc2 1 -prof_time 4 -devirt_indir 1 -devirt_only_terminators 1 -- ./cc1 expr.i
```

- -create_tc2 1: Build a second cache after the profiling window and switch TC→TC2 once.
- -prof_time 4: Collect BBL counters for 4 seconds before building TC2.
- -devirt_indir 1: Enable guarded devirtualization for hot indirect branches in TC2.
- -devirt_only_terminators 1: Only apply devirt to BBL-terminating indirect sites (safer layout).

Optional additions
- -devirt_calls_too 1: Include indirect CALL sites in devirtualization.
- -use_killed_regs 0: Disable killed-register fast path if you suspect counter insertion issues.
- -prof_indir 1: Also collect indirect target histograms in TC1 (higher overhead).

## Flags explained (quick reference)
- -verbose (default 0): Extra diagnostic prints during TC build, fixups, and commit. Slightly noisier; negligible overhead.
- -dump_orig_code (default 0): Disassemble original image code. Use for debugging mapping/decoding.
- -dump_tc / -dump_tc2 (default 0): Disassemble the constructed TC1/TC2. Helpful to verify fixups and devirt materialization.
- -no_tc_commit (default 1): If 1, don’t commit and the app runs natively. Set 0 to commit and execute from TC. Tip: start with 1 for baseline runs, then flip to 0.
- -create_tc2 (default 0): Enable a background TC2 build after profiling and switch TC→TC2 once. Logs a single "[TC2 SWITCH] …" when committing.
- -prof_time <secs> (default 2): Duration for BBL profiling before TC2 is built. Larger windows improve profile quality but delay the switch.
- -commit_limit <N> (default 0 = unlimited): Limit how many routines get committed to TC/TC2. Great for staged rollouts and isolating bad commits.
- -quiet_distance (default 0): Suppress per-routine ">2GB distance" logs; print a concise commit summary instead.
- -prefer_near_text (default 1): Hint allocator to place TC near original .text to reduce distance skips.
- -probe_back_jumps (default 0; only with -create_tc2): Pre-place probe slots (wide NOPs) at routine prologs and before backward jumps to aid TC→TC2 switching.
- -no_code_reorder (default 0; only for TC2): Keep TC2 instruction order identical to TC1. Safer for conservative layouts; may reduce TC2 quality.
- -devirt_indir (default 0; only affects TC2): Enable guarded devirtualization for hot indirect branches (JMP/CALL). Emits MOV/CMP/JNZ fast path + original slow path.
- -devirt_only_terminators (default 1; with -devirt_indir): Restrict devirt to BBL-terminating indirects for layout safety.
- -devirt_calls_too (default 0; with -devirt_indir): Also consider indirect CALL sites (riskier; verify carefully).
- -indir_hot_pct <0..100> (default 80; with -devirt_indir): Minimum percentage share the hottest target must have in that BBL to qualify.
- -indir_min_count <N> (default 100; with -devirt_indir): Minimum executions of the BBL/site before considering devirt.
- -use_killed_regs (default 1; TC1 profiling): Use a detected killed register for low-overhead BBL counters; prefers RAX so moffs64 MOV can be used with no saves.
- -prof_indir (default 0): Also profile indirect branch targets (histograms) in TC1. Higher overhead—enable only when you need target distribution data.

### Interactions and precedence
- -create_tc2 is required for any TC2 or devirtualization behavior to take effect; devirt flags apply to TC2 only.
- -devirt_* thresholds (-indir_hot_pct, -indir_min_count) are used only when -devirt_indir 1.
- -probe_back_jumps and -no_code_reorder are relevant to the TC2 pipeline; they’re ignored for TC1-only runs.
- -use_killed_regs only changes how TC1 profiling counters are injected; it does not affect functional code gen.
- Environment override: PIN_NO_TC_COMMIT=1 forces no commit even if -no_tc_commit 0 is passed.

### Performance notes
- TC creation (decode/encode/copy) time is logged; exclude it from overhead calculations per spec.
- Lowest overhead path: -use_killed_regs 1, keep -prof_indir 0, and commit a small subset first (-commit_limit).
- Indirect-target profiling (-prof_indir 1) and verbose dumps (-dump_tc*, -dump_prof) increase overhead; use only for diagnostics.
- If you see "skipped due to >2GB distance" on commit, TC memory landed too far for safe rel32 probe jumps. That’s OK—the tool keeps execution safe and native for those routines.
	Use `-quiet_distance 1` to reduce noise; you’ll see an end-of-pass line like `commit summary: success=..., invalid=..., unsafe=..., far>2GB=..., replace_failed=...`.

## Windows examples (PowerShell)
```powershell
$env:PIN_NO_TC_COMMIT = "1"
& "$env:PIN_ROOT\pin.exe" -t ".\obj-intel64\project.dll" -- "C:\path\to\app.exe" "args"
Remove-Item Env:PIN_NO_TC_COMMIT -ErrorAction SilentlyContinue
& "$env:PIN_ROOT\pin.exe" -t ".\obj-intel64\project.dll" -no_tc_commit 0 -create_tc2 1 -prof_time 4 -devirt_indir 1 -devirt_only_terminators 1 -- "C:\path\to\app.exe" "args"
```

## Expected logs
- after memory allocation / identifying candidate routines / chaining …
- after write all new instructions to memory tc / tc2
- after commit of translated routines from orig code to TC
- [TC2 SWITCH] Committing jump from TC to TC2 … (exactly once)

## Benchmark like the screenshot (Linux)
```bash
export PIN_ROOT=~/pin-3.31
# NATIVE / TC2_NO_COMMIT / TC2_COMMIT / TC2_DEVIRT (if USE_DEVIRT=1)
gunzip -kf ./input-long.txt.gz  # ensure ./input-long.txt exists
RUNS=5 USE_DEVIRT=1 ./tools/bench.sh --app /usr/bin/bzip2 -- -k -f ./input-long.txt
```

If your pintool .so isn’t at `obj-intel64/project.so`, set TOOL to your build output path. Example using your SimpleExamples build folder:
```bash
export PIN_ROOT=~/pin-3.31
TOOL=/home/binarym/Downloads/pin-3.30-98830-g1d7b601b3-gcc-linux/source/tools/SimpleExamples/obj-intel64/project.so \
	RUNS=5 USE_DEVIRT=1 ./tools/bench.sh --app /usr/bin/bzip2 -- -k -f ./input-long.txt
```

Columns:
- dur_s: wall time for whole run
- create_tc_s: time reported by the tool to build TC (exclude when judging overhead)
- post_user_s: dur_s - create_tc_s (bounded at 0)
- taskclk_ms, ctx_sw, cpu_migr, page_faults: from `perf stat` when available
