---
marp: true
paginate: true
headingDivider: 2
---

# Dynamic Translation and Optimization of Binary Code (046275)

Spring 2025  \\
Ayman Atiea — 324300656  \\
Ferass Khoury — 211582697  \\
Lecturer: Gadi Haber

Notes:
- Probe-mode Pintool: TC1 → Profile → TC2.

---

## Agenda

- Introduction
- The Problem
- Implementation
- Results
- Conclusion & Future Work

Notes:
- Follow the flow on each slide as breadcrumb.

---

## Introduction

- We built a Pintool (Probe mode) that performs dynamic binary translation (DBT)
- Two-phase execution:
  - Profiling Phase (TC1): collect BBL heat and optional indirect target histograms
  - Optimized Phase (TC2): build a second cache and switch once
- Goal: stay within ≤15% overhead (excluding TC build time)

Notes:
- Emphasize that probe mode keeps overhead low.

---

## The Problem

- DBT can be slow if profiling is heavy
- Indirect JMP/CALL are unpredictable → lost optimizations
- Switching between caches can add overhead or instability
- Core question: How to profile accurately and still run near-native speed?

Notes:
- Lead into our design decisions.

---

## Our Approach (High Level)

- Build TC1 with low-overhead BBL counters (prefer killed register fast-path)
- Run for a short profiling window
- Build TC2 using profiling data and guarded devirtualization for hot indirects
- Switch once from TC1 → TC2 using a probed jump; then keep running from TC2

Notes:
- One-time switch. Keep it simple and safe.

---

## Implementation Overview

- ImageLoad pipeline builds TC1: decode → chain → layout → fixups → copy → commit
- Background thread builds TC2: disable counters → plan devirt → fixups → copy → switch
- Safety: ±2GB distance guard; commit limit; probe-safe routines only

```cpp
VOID ImageLoad(IMG img, VOID *v) {
  allocate_and_init_memory(img);
  create_tc(img);
  chain_all_direct_br_and_call_target_entries(0, num_of_instr_map_entries);
  set_initial_estimated_new_ins_addrs_in_tc(tc);
  fix_instructions_displacements();
  copy_instrs_to_tc(tc);
  if (!KnobDoNotCommitTranslatedCode && !getenv("PIN_NO_TC_COMMIT"))
    commit_translated_rtns_to_tc();
}
```

Notes:
- Show end-to-end flow.

---

## Profiling Phase (TC1)

- Counters at BBL terminators; fast path uses a killed register (RAX) when safe
- Optional indirect-target histograms for JMP/CALL (off by default)

```cpp
// add_profiling_instrs(...)
// Fast: use killed RAX → no saves
// Fallback: save/restore RAX; load/inc/store counter
```

Notes:
- Low overhead by design.

---

## Fixups & Layout

- RIP-relative: recompute disp32 from new PC to same absolute
- Direct calls/branches: rel32 to TC target or out-of-TC rewrite via [rip+slot]
- Converging loop until sizes stabilize (two-pass via XED encode)

```cpp
int fix_instructions_displacements(){
  int size_diff=0; do{ size_diff=0; for(i){
    new_addr += size_diff;
    s=fix_rip_displacement(i); if(s>0){size_diff+=s-size; size=s; continue;}
    s=fix_direct_br_or_call_displacement(i); if(s>0){size_diff+=s-size; size=s;}
  }}while(size_diff!=0);
}
```

Notes:
- Deterministic convergence.

---

## Optimized Phase (TC2)

- Disable profiling stubs in-place
- Plan guarded devirtualization for hot indirect JMP/CALL
- Re-chain, re-layout, fixups, copy to TC2, then switch once

```asm
mov scr, imm64 <hot>
cmp targReg, scr
jnz slow
  jmp/call rel32 <hot>
slow: original indirect
```

Notes:
- Guarded fast path with safe slow path.

---

## Safety & Correctness

- Probe-safe check + ±2GB distance guard for commits
- Commit limit for staged rollout
- One-time TC2 switch with explicit log: "[TC2 SWITCH]"

Notes:
- If far, routine stays native.

---

## Knobs (Selected)

- -create_tc2, -prof_time: enable/interval for TC2
- -use_killed_regs: prefer fast profiling path
- -prof_indir: enable indirect-target histograms
- -devirt_indir, -devirt_calls_too, -devirt_only_terminators
- -indir_hot_pct, -indir_min_count: devirt thresholds

Notes:
- Defaults conservative; enable selectively.

---

## Results (Placeholders)

- Overhead vs Native (%): [Insert chart]
- Switch timing: [Insert timeline]
- Devirt hit-rate: [Insert table]

Notes:
- Replace with your actual measurements.

---

## Logs & Verification

- Milestones: allocation / chaining / fixups / copy / commit
- Skips: ">2GB distance" → routine stays native
- Switch: "[TC2 SWITCH] …" appears once

Notes:
- Use -dump_tc/-dump_tc2/-dump_prof for validation.

---

## Conclusion

- Two-phase DBT keeps profiling cheap and optimization effective
- Guarded devirt speeds predictable indirects without sacrificing safety
- Fits ≤15% overhead goal (excluding TC build) with proper knob tuning

Notes:
- Close with future work.

---

## Future Work

- Out-of-line devirt thunks for larger stubs
- Finer-grained profiling windows; adaptive thresholds
- More aggressive scheduling when safe

Notes:
- Keep roadmap realistic.

---

## Q&A

- What is ImageLoad? Pin callback per image; orchestrates TC1
- How do we ensure safety? Probe-safe + ±2GB guard + commit limit
- How does devirt pick targets? Per-BBL histogram share & count gates
- How to prove switch? One-time "[TC2 SWITCH]" log

Notes:
- Thank the audience.
