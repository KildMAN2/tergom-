# Project Pintool: Code Overview

This document explains how the Probe-mode Pintool in `src/project.cpp` works, with short code excerpts and pointers to key functions.

## Big picture: TC1 → profile → TC2 → switch

- Image load (`ImageLoad`): build Translation Cache 1 (TC1) from the main executable.
- TC1 execution: optionally commit routines so the app runs from TC1; collect low-overhead BBL counters (and optionally indirect-target histograms).
- TC2 thread (`create_tc2_thread_func`): after a profiling window, disable profiling code in TC1, build TC2, optionally materialize guarded devirtualization, then switch execution from TC to TC2 once.
- Safety: guard probed commits by distance (≤2GB), limit commits, and prefer near allocation.

## Core data structures

- Instruction map (`instr_map_t`): one row per translated instruction.
  - Tracks original address, encoded bytes, size, BBL id, and mapping to targets.
  - Also carries devirtualization planning/materialization fields for TC2.

```cpp
// src/project.cpp (simplified)
typedef struct {
  ADDRINT orig_ins_addr;      // original image address (mutated to TC1 addr for TC2 build)
  ADDRINT saved_orig_addr;    // immutable original image address (stable identity)
  ADDRINT new_ins_addr;       // destination address in TC (or TC2)
  ADDRINT orig_targ_addr;     // if direct branch/call, original target
  ins_enum_t ins_type;        // RegularIns / RtnHeadIns / ProfilingIns
  char encoded_ins[XED_MAX_INSTRUCTION_BYTES];
  unsigned int size;          // current encoded size
  int targ_map_entry;         // index in instr_map of the resolved target
  unsigned bbl_num;           // owning basic block id
  xed_category_enum_t xed_category;
  // TC2 devirtualization bookkeeping
  bool devirt_planned;
  int  devirt_target_entry;
  bool devirt_is_call;
} instr_map_t;
```

- BBL map (`bbl_map_t`): per-basic-block counters and optional indirect target histograms.

```cpp
typedef struct {
  UINT64 counter;             // BBL exec count
  UINT64 fallthru_counter;    // fallthrough count for cond-branches
  ADDRINT targ_addr[4];       // small histogram of indirect targets
  UINT64  targ_count[4];
  unsigned starting_ins_entry;
  unsigned terminating_ins_entry;
  UINT32 killed_reg;          // detected scratch reg at BBL head (or REG_INVALID)
} bbl_map_t;
```

## Build TC1: the `ImageLoad` pipeline

`ImageLoad` orchestrates TC1 construction and (optionally) committing routines to run from TC1.

```cpp
VOID ImageLoad(IMG img, VOID *v) {
  allocate_and_init_memory(img);                  // prefer near mapping, size structures
  create_tc(img);                                  // decode/encode, build instr_map & bbl_map
  chain_all_direct_br_and_call_target_entries(0, num_of_instr_map_entries);
  set_initial_estimated_new_ins_addrs_in_tc(tc);   // lay out linear addresses
  fix_instructions_displacements();                // RIP and branch fixups (via XED)
  tc_size = copy_instrs_to_tc(tc);                 // materialize bytes into TC memory
  if (!KnobDoNotCommitTranslatedCode && !envNoCommit)
    commit_translated_rtns_to_tc();                // probed replacement with distance guard
}
```

Key steps:
- Chaining: resolve direct branches/calls to map entries so relative displacements can be re-encoded.
- Fixups: recalculate RIP-relative and branch displacements after addresses are set.
- Commit: replace safe routines with TC counterparts using Pin’s probed replacement.

## Profiling in TC1: low overhead counters

At BBL boundaries the tool injects a small counter bump, prioritizing a “killed register” path (ideally RAX) to avoid saves/restores. This keeps overhead low and helps meet the ≤15% goal.

```cpp
// add_profiling_instrs(...)
if (IsGoodKilledReg(killed_reg) && PinRegToXedReg(killed_reg) == XED_REG_RAX) {
  // Fast path: MOV RAX, [counter]; LEA RAX, [RAX+1]; MOV [counter], RAX
} else {
  // Conservative path: save RAX; load/increment/store; restore RAX
}
```

Optional: with `-prof_indir 1`, extra instructions collect a small histogram of indirect branch targets (higher overhead; off by default).

## TC2 thread: building and switching

`create_tc2_thread_func` runs after `-prof_time` seconds.

```cpp
void create_tc2_thread_func(void*) {
  disable_profiling_in_tc(instr_map, num_of_instr_map_entries);    // patch profile stubs to NOP/jump
  // Prepare instr_map for TC2 build
  for (i: instrs) { instr_map[i].orig_ins_addr = instr_map[i].new_ins_addr; /* reset sizes for NOPs, etc. */ }
  if (KnobDumpProfile) dump_entire_instr_map_with_prof();
  // Devirt planning & chaining
  if (KnobDevirtIndirects) for (i) plan_devirtualization_for_idx(i, instr_map[i].bbl_num);
  chain_all_direct_br_and_call_target_entries(0, num_of_instr_map_entries);
  set_initial_estimated_new_ins_addrs_in_tc(tc2);
  if (KnobDevirtIndirects) for (i) materialize_devirtualization(i); // guarded fast paths
  fix_instructions_displacements();
  tc2_size = copy_instrs_to_tc(tc2);
  if (!KnobDoNotCommitTranslatedCode && !envNoCommit)
    commit_translated_rtns_to_tc2(); // one-time "[TC2 SWITCH]" log
}
```

### Guarded devirtualization (TC2 only)

For hot, predictable indirect branches (and optional calls), TC2 replaces the original indirect with a guarded fast path:

```
MOV SCR, imm64(hot_target)
CMP TARGET_REG, SCR
JNZ slowpath
  <direct rel32 JMP/CALL hot_target>
slowpath:
  <original indirect bytes>
```

Planning filters sites by:
- Heat gates: `-indir_min_count` and `-indir_hot_pct` share.
- Kind gates: `-devirt_only_terminators` and (optional) `-devirt_calls_too`.
- Feasibility: must be reg-indirect and have a safe scratch register.

Materialization happens before fixups/copy so layout is consistent and safe.

## Safety and allocation

- Near allocation for TC/TC2 (best-effort): increases chances that rel32 probes and branches are in range.
- Distance guard on commit (TC1): skip `RTN_ReplaceProbed` when replacement is >2GB away.
- Commit limiter `-commit_limit`: stage rollouts during bring-up.

```cpp
// commit_translated_rtns_to_tc()
long long delta = (long long)new_addr - (long long)RTN_Address(rtn);
if ((unsigned long long)(delta < 0 ? -delta : delta) > 0x7fffffffULL) {
  // skip; keep execution safe and native here
}
```

## Encoding helpers (XED)

Small utilities encode common sequences used by the tool:
- `encode_direct_relbr(pc, target, is_call, out, olen)` → direct rel32 JMP/CALL
- `encode_jcc_rel32(pc, target, jcc, out, olen)` → rel32 conditional branch
- `encode_mov_imm64(dst_r64, imm64, out, olen)` → load 64-bit immediate
- `encode_cmp_rr(rA, rB, out, olen)` → register compare

These underpin guarded devirtualization and various fixups.

## Knobs and logs

- See `docs/USAGE.md` for detailed flags, defaults, and interactions.
- Expected logs include milestones like:
  - after memory allocation / chaining / fixing displacements
  - after write all new instructions to memory tc / tc2
  - after commit of translated routines from orig code to TC
  - [TC2 SWITCH] Committing jump from TC to TC2 … (exactly once)

## Debugging tips

- Use `-dump_tc` and `-dump_tc2` to confirm encodings and guarded sequences.
- Use `-dump_prof` to correlate BBL heat and devirt planning decisions.
- Start with `PIN_NO_TC_COMMIT=1` or `-commit_limit 1` to validate safely, then expand.

---

If you want this linked from the main README or to add a short “recipes” section (lowest overhead vs. strongest devirt vs. diagnostics), say the word and we’ll wire it up.

## Mini glossary

- IMG: Pin handle for a loaded image (exe or shared library).
- RTN: Pin handle for a routine/function inside an image.
- BBL: Basic block (sequence of instructions with single entry and exit).
- TC/TC2: Translation Cache 1 (profiling) and Translation Cache 2 (optimized).
- Probe mode: Low-overhead patching at routine entries using short probes; no trampolines.
- RIP-relative: x86-64 addressing that uses instruction pointer-relative displacements.
- rel32: 32-bit relative displacement used by calls/branches; limits reach to ±2GB.
- Devirtualization: Converting an indirect branch/call into a guarded direct one for the hot target.

## Function-by-function guide

- allocate_and_init_memory(img)
  - Scans executable sections to bound the code address range and estimate TC size.
  - Allocates `instr_map`, `bbl_map`, and `jump_to_orig_addr_map`.
  - Tries to mmap TC and TC2 contiguously (preferring near addresses on x86-64).

- create_tc(img)
  - Walks all routines and instructions, decoding via XED and pushing entries to `instr_map`.
  - Identifies BBL boundaries (terminators or next target) and initializes `bbl_map` indices.
  - When profiling is enabled, injects profiling stubs at BBL ends and conditional fallthroughs.
  - For prologs/back-jumps (under `-probe_back_jumps`) inserts a wide NOP slot used for probed TC→TC2 jump.

  Example:

  // ...existing code...
  // at the end of each BBL, add a low-overhead counter
  rc = add_profiling_instrs(ins, ins_addr, &bbl_map[bbl_num].counter, bbl_num, killed);
  // also record fallthroughs when enabled
  rc = add_profiling_instrs(ins, ins_addr, &bbl_map[bbl_num - 1].fallthru_counter, bbl_num-1, kr);
  // ...existing code...

- ImageLoad(img, v)
  - Registered with `IMG_AddInstrumentFunction(ImageLoad, 0);` and called per loaded image.
  - High-level steps executed here for each image:
    1) allocate_and_init_memory(img)
    2) create_tc(img)
    3) chain_all_direct_br_and_call_target_entries(…)
    4) fix_instructions_displacements()
    5) copy_instrs_to_tc(tc)
    6) commit_translated_rtns_to_tc()
    7) If `-create_tc2`, spawn `create_tc2_thread_func` for profiling window and TC2 switch.

  Example skeleton:

  // ImageLoad(img, v)
  //   allocate_and_init_memory(img);
  //   create_tc(img);
  //   chain_all_direct_br_and_call_target_entries(0, n);
  //   fix_instructions_displacements();
  //   copy_instrs_to_tc(tc);
  //   commit_translated_rtns_to_tc();
  //   if (KnobApplyThreadedCommit) PIN_SpawnInternalThread(create_tc2_thread_func, …);

- add_new_instr_entry(xedd, pc, type)
  - Encodes the decoded instruction back to bytes, stores metadata (orig addr, disp-derived target if direct), size, BBL id, and category.

- add_profiling_instrs(ins, addr, counter*, bbl, killed)
  - Emits a small sequence that increments the BBL counter.
  - Fast path: if the killed register is RAX, uses moffs64 with no save/restore.
  - Fallback: save RAX to a spill slot, increment, and restore.
  - Optional indirect-target profiling (`-prof_indir`) adds MOV/AND/LEA/MOV sequence to fill `bbl_map[bbl].targ_addr/count` buckets, saving/restoring RBX/RCX if needed.

  Example key paths:

  // Fast path using killed RAX with moffs64
  // inc qword ptr [abs64 counter]
  // ... no save/restore needed

  // Conservative path
  // push rax; mov rax, [counter]; add rax, 1; mov [counter], rax; pop rax

  // Optional indirect-target histogram (when -prof_indir)
  // mov rbx, [targ]; and rbx, mask; lea rcx, [bucket_base + rbx]; inc qword ptr [rcx]

- chain_all_direct_br_and_call_target_entries(from, until)
  - Builds a map from original instruction addresses to their indices, then resolves direct branch/call targets to indices (`targ_map_entry`).

  Example:

  // ...existing code...
  if (is_direct_relbr_or_call(e)) {
    auto it = orig_to_idx.find(e.orig_targ_addr);
    if (it != orig_to_idx.end()) instr_map[i].targ_map_entry = it->second;
  }
  // ...existing code...

- set_initial_estimated_new_ins_addrs_in_tc(tc)
  - Linearly assigns `new_ins_addr` across the TC buffer by accumulating `size` per entry (current best estimate prior to fixups).

- fix_rip_displacement(i)
  - For RIP-relative memory operands, recalculates the effective displacement to the original absolute target, then re-encodes with the correct new PC (two-pass to settle size).

  Example recompute:

  // new_disp = (orig_abs - (new_pc + instr_len))
  // xed_encode with updated displacement; if size changes, loop in fixups

- fix_direct_br_or_call_displacement(i)
  - For direct branches/calls with known `targ_map_entry`, recomputes the rel32 (two-pass to settle size).
  - If target is outside the TC (kept as original), rewrites to an indirect via RIP-relative memory pointing to `jump_to_orig_addr_map`.

  Example:

  // if (target_in_tc)
  //   encode rel32 from new_pc to target_new_pc
  // else
  //   jmp [rip + slot]; slot holds absolute original target

- fix_instructions_displacements()
  - Iterates until sizes stabilize. For each entry, adjusts `new_ins_addr` by the running `size_diff`, then applies RIP/branch fixups. Repeats while any size changed.

  Example driver loop:

  // do {
  //   changed = false; size_diff = 0;
  //   for i in entries:
  //     new_addr = base + offset + size_diff; fix rip; fix branches; if size changed -> changed=true; size_diff += delta;
  // } while (changed)

- copy_instrs_to_tc(tc)
  - Copies each entry’s `encoded_ins[..size]` into the mapped TC at its `new_ins_addr` offset.

- commit_translated_rtns_to_tc()
  - For each routine head entry, checks `RTN_IsSafeForProbedReplacement` and that the TC target is within ±2GB before calling `RTN_ReplaceProbed`.
  - Obeys `-commit_limit` to limit blast radius during bring-up.

  Example guard:

  // if (llabs((INT64)(tc_addr - orig_addr)) > 0x7fff'ffff)
  //   skip; // avoid 32-bit disp overflow in probes

- create_tc2_thread_func(void*)
  - Sleeps `-prof_time`, patches TC1 profiling stubs to NOP/jumps (`disable_profiling_in_tc`).
  - Remaps `orig_ins_addr` to TC1 addresses, clears devirt state, removes profiling/NOP entries (`size=0`).
  - Optionally plans devirt per site (heat/share/kind gates + feasibility), re-chains, lays out TC2 addresses, materializes guarded fast paths in-place, fixes displacements, then copies and commits TC→TC2 (one-time "[TC2 SWITCH]" log).

  Example skeleton:

  // disable_profiling_in_tc(instr_map, n);
  // for each bbl and index i: plan_devirtualization_for_idx(i,bbl_id);
  // chain_all_direct_br_and_call_target_entries(0,n);
  // fix_instructions_displacements();
  // copy_instrs_to_tc(tc2); commit_translated_rtns_to_tc2();

- plan_devirtualization_for_idx(i, bbl)
  - Considers only indirect reg-based JMP/CALL (RET excluded). If `-devirt_only_terminators` is set, requires BBL terminator. Requires minimum executions and hot target share thresholds. Ensures a scratch register exists. Maps hot target to a TC2 entry via `saved_orig_addr`.

  Example heat/predictability gates:

  // if (bbl_count < indir_min_count) return 0;
  // if ((hot_bucket.count / total) * 100 < indir_hot_pct) return 0;
  // if (!choose_scratch_reg_for_idx(i,&scr)) return 0;

- emit_guarded_devirt(i)
  - Encodes MOV/CMP/JNZ + direct rel32 fast path + original slow path into a temporary buffer, then replaces the entry’s bytes and updates `size`.
  - Runs before fixups so subsequent layout/fixups account for the new size.

  Example structure:

  // mov scr, imm64(target);
  // cmp targReg, scr;
  // jnz slow_path;
  //   [fast path] jmp/call rel32 target;
  // slow_path:
  //   original indirect jmp/call

## Data flow and lifetimes

- TC1 build uses original image addresses as `orig_ins_addr` and sets `saved_orig_addr = orig` for durable identity.
- On TC2 build, `orig_ins_addr` is replaced with the TC1 address for local fixups; `saved_orig_addr` remains the handle to map back to original targets.

## Edge cases and safeguards

- >2GB distance: probed replacement is skipped to keep execution safe and native for those routines.
- Size churn: fixups loop until sizes stabilize; any encoded size increase is propagated to subsequent entries via `size_diff`.
- Conditional branches: short encodings may be promoted to rel32 to fit the new displacement.
- Indirect to original code: rewritten as indirection via a small RIP-relative slot (`jump_to_orig_addr_map`) to maintain reachability.

## Tuning knobs in code paths (quick map)

- `KnobDoNotCommitTranslatedCode` and env `PIN_NO_TC_COMMIT`: skip TC commits entirely.
- `KnobApplyThreadedCommit` (`-create_tc2`): enables TC2 thread and TC→TC2 probing.
- `KnobUseKilledRegs`: toggles fast vs. conservative counter injection in `add_profiling_instrs`.
- `KnobProfileIndirectTargets` (`-prof_indir`): enables heavier target-histogram profiling in TC1.
- `KnobDevirtIndirects` (+ `KnobDevirtOnlyTerminators`, `KnobDevirtCallsToo`, `KnobIndirectHotPct`, `KnobIndirectMinCount`): govern planning/materialization of guarded devirt paths in TC2.

## Known caveats and future hardening

- Guarded devirt stub size: the in-place guarded sequence often exceeds 15 bytes (XED_MAX_INSTRUCTION_BYTES). If `encoded_ins` is a fixed-size 15-byte buffer, don’t copy a larger blob into it. Two safer patterns:
  1) Out-of-line thunk: patch the site with a 5-byte JMP rel32 to a stub appended at the end of TC2; emit the guarded sequence there.
  2) Dynamic per-entry storage: store bytes in a small heap buffer (vector) per entry and copy from it; removes the 15-byte limit.
- Address proximity: even with best-effort near mapping, some binaries will map TC far from text; expect benign "skipped due to >2GB distance" logs.

## Quick FAQ

- Why reuse `instr_map` for TC2 instead of rebuilding? 
  To avoid re-decoding and re-wiring everything. By rewriting entries pre-fixups and re-running layout/fixups, TC2 naturally accounts for new sizes.

- How does the tool know the hot target for devirt? 
  From `bbl_map[bbl].targ_addr/count` histograms (if collected) and the BBL heat; it checks both minimum count and share thresholds.

- What ensures TC2 switch happened? 
  A single "[TC2 SWITCH]" log is printed when the probed TC→TC2 patch is committed at the first eligible slot.

## Q&A for presentation

- What is ImageLoad?
  - It’s a Pin callback invoked when a new image (executable or shared library) is loaded into the process. We register it with `IMG_AddInstrumentFunction(ImageLoad, 0);` so Pin calls our `ImageLoad(IMG img, VOID* v)` for each image.
  - In this tool, `ImageLoad` orchestrates the entire pipeline for that image: memory allocation, TC1 build, fixups, copying bytes to TC, and probed commit. If `-create_tc2` is enabled, it also spawns a thread that later constructs TC2 and switches execution.

- When is ImageLoad called relative to program start?
  - Pin calls it after the image is mapped but before execution reaches most routines in that image. That’s early enough to build and commit TC1 for many routines before first use. Additional shared libraries loaded later also trigger `ImageLoad` again.

- What does `RTN_ReplaceProbed` do here?
  - It atomically patches the routine entry with a short probe that redirects execution to our translated routine (TC or TC2) in probe mode. We guard it with `RTN_IsSafeForProbedReplacement` and a ±2GB distance check to ensure the short probe encoding is safe.

- Why the ±2GB distance guard?
  - Probes typically rely on 32-bit relative displacements. If the TC address is more than 2GB away from the original routine, the rel32 won’t reach, and the patch would be unsafe. We skip such routines and leave them running natively.

- What’s `commit_limit` used for?
  - It caps how many routines we commit in one pass. That’s useful for staged bring-up and debugging. Set `-commit_limit 0` to commit all routines.

- How do we switch from TC1 to TC2?
  - After `-prof_time`, the background thread disables TC1 profiling in-place, plans/materializes devirt, rebuilds layout and fixups for TC2, then uses a probed jump from TC1 prologs/back-jumps to TC2 entry, logging a one-time “[TC2 SWITCH]”.

- What is a BBL and why profile at BBL boundaries?
  - A Basic Block has a single entry and exit, making its counter updates precise and low-cost. Ending at terminators captures hot paths and indirect branch activity.

- What are RIP fixups and why needed?
  - RIP-relative displacements change when we relocate code into TC/TC2. We recompute displacements based on the new PC and re-encode to keep memory references correct.

- Why plan devirtualization before fixups?
  - Guarded stubs change instruction sizes and layout. Planning and materializing before fixups allows the fixup loop to converge on correct sizes/addresses.

- What if devirt stub is larger than original encoded size?
  - Our pipeline runs layout/fixups after materialization so size growth is handled. If you ever exceed per-entry storage, switch to an out-of-line thunk or dynamic storage as noted above.

## Appendix A – Data structures (field-by-field)

- instr_map_t (one per decoded instruction)
  - orig_ins_addr: original image PC of this instruction (later reused as TC1 PC during TC2 build; original kept in saved_orig_addr).
  - saved_orig_addr: immutable original PC used to map back to the real image address for lookups and devirt.
  - new_ins_addr: PC inside the current TC buffer where this instruction will live (computed after layout/fixups).
  - orig_targ_addr: absolute target when the instruction was a direct branch/call (from decode phase).
  - targ_map_entry: index into instr_map of the target instruction when target is within TC; otherwise -1.
  - encoded_ins: bytes of the instruction as currently (re-)encoded (updated by fixups and devirt).
  - size: current byte length of encoded_ins. May change during fixups and devirt materialization.
  - bbl_num: owning basic block ID (index into bbl_map).
  - xed_category: instruction category (e.g., COND_BR, CALL) used for policy decisions.
  - ins_type: tag for special sites (routine head, back-jump probe slot) to enable safe commits and TC1→TC2 jumps.
  - devirt_*: flags/metadata for TC2 guarded devirtualization (is_devirt_site, is_call, chosen target, scratch reg).

- bbl_map_t (one per basic block)
  - counter: execution count for the BBL (incremented in TC1).
  - fallthru_counter: count for the fallthrough edge from this BBL when applicable (optional).
  - targ_addr[NUM_BUCKETS]: buckets of observed indirect targets’ low bits (when -prof_indir).
  - targ_count[NUM_BUCKETS]: per-bucket counts aligned with targ_addr.
  - start_ins_map_entry: index of the first instruction in this BBL within instr_map.
  - end_ins_map_entry: index of the BBL terminator instruction within instr_map.
  - killed_reg: register identified as safely clobbered within this BBL, enabling the fast-path counter.

- jump_to_orig_addr_map
  - Small array of absolute target pointers placed near TC, letting us rewrite unreachable direct branches as RIP-relative memory indirections.

## Appendix B – Flags (flag-by-flag)

- -verbose: print detailed logs and dumps for debugging.
- -dump_orig_code: dump original instructions per routine.
- -dump_tc: dump TC1 after fixups/copy.
- -dump_tc2: dump TC2 after fixups/copy.
- -no_tc_commit: don’t commit any translated code (also honored via env PIN_NO_TC_COMMIT=1).
- -create_tc2: enable profiling window and TC1→TC2 switch.
- -commit_limit=N: limit number of routines to commit in a pass (0 = no limit).
- -prof_time=S: seconds to profile before building TC2.
- -dump_prof: dump BBL/indirect-target counters.
- -probe_back_jumps: reserve probe slots at prologs and backward jumps to enable TC1→TC2 jump.
- -no_code_reorder: keep original instruction order; disables scheduling tricks.
- -devirt_indir: attempt guarded devirtualization of hot indirect branches in TC2.
- -devirt_calls_too: allow devirtualization of indirect CALLs (default off for safety).
- -devirt_only_terminators: only consider devirt at BBL terminators.
- -indir_hot_pct=P: minimum percentage share for a single hot target within a BBL’s indirect-target histogram to consider devirt.
- -indir_min_count=C: minimum BBL execution count required before devirt is considered.
- -use_killed_regs: prefer fast-path profiling that uses a killed register (RAX favored) to avoid save/restore.
- -prof_indir: collect per-BBL indirect-target histograms (heavier overhead; enables smarter devirt decisions).

Defaults and interplay:
- By default, TC1 profiling uses fast path when possible and disables heavy target histograms unless -prof_indir is set.
- Devirt requires -devirt_indir; CALL sites need -devirt_calls_too; terminator restriction via -devirt_only_terminators.
- commit_limit is 0 by default (no limit); ±2GB guard always applies.

## Annotated code excerpts (real snippets)

These are short, real code slices from `src/project.cpp` to show how it’s implemented.

### ImageLoad: pipeline orchestration

```cpp
VOID ImageLoad(IMG img, VOID *v)
{
    if (!IMG_IsMainExecutable(img))
      return;
    int rc = allocate_and_init_memory(img);
    if (rc < 0) return;
    rc = create_tc(img);
    if (rc < 0) return;
    chain_all_direct_br_and_call_target_entries(0, num_of_instr_map_entries);
    set_initial_estimated_new_ins_addrs_in_tc(tc);
    rc = fix_instructions_displacements();
    if (rc < 0) return;
    rc = copy_instrs_to_tc(tc);
    if (rc < 0) return;
    if (!KnobDoNotCommitTranslatedCode && !getenv("PIN_NO_TC_COMMIT"))
      commit_translated_rtns_to_tc();
}
```

### create_tc: prolog/back-jump probe slot + BBL profiling

```cpp
// Insert a NOP7 at RTN head or before a back jump (for TC1→TC2 probe)
if (KnobApplyThreadedCommit && (isRtnHeadIns || isInsBackwardJump)) {
  xed_inst0(&enc_instr, dstate, XED_ICLASS_NOP7, 64);
  // encode+decode, then add into instr_map as a special entry
  rc = add_new_instr_entry(&xedd, ins_addr, ins_type);
  ins_type = RegularIns;
}

// BBL terminate? insert low-overhead counter
if (KnobApplyThreadedCommit && isInsTerminatesBBL) {
  REG killed = KnobUseKilledRegs ? findKilledRegNearBblHead(...) : REG_INVALID();
  bbl_map[bbl_num].killed_reg = (UINT32)killed;
  rc = add_profiling_instrs(ins, ins_addr, &bbl_map[bbl_num].counter, bbl_num, killed);
}

// Edge profiling after a conditional branch
if (KnobApplyThreadedCommit && INS_Category(ins) == XED_CATEGORY_COND_BR) {
  REG kr = (REG)bbl_map[bbl_num - 1].killed_reg;
  rc = add_profiling_instrs(ins, ins_addr, &bbl_map[bbl_num - 1].fallthru_counter, bbl_num-1, kr);
}
```

### add_profiling_instrs: fast vs conservative paths

```cpp
// Emit a WIDENOP so we can later replace it with a skip-jump
xed_inst0(&enc_instr, dstate, XED_ICLASS_NOP4, 64);
add_prof_instr(ins_addr, &enc_instr);

// Optional indirect-target profiling for JMP/CALL (heavier)
if (KnobProfileIndirectTargets && INS_IsIndirectControlFlow(ins) && !INS_IsRet(ins)) {
  // Save RAX (to rax_mem), spill RBX/RCX, load target into RAX,
  // bucketize and increment per-BBL histogram, then restore.
  xed_inst2(&enc_instr, dstate, XED_ICLASS_MOV, 64,
            xed_mem_bd(XED_REG_INVALID, xed_disp((ADDRINT)&rax_mem, 64), 64),
            xed_reg(XED_REG_RAX));
  // ... more MOV/LEA/INC as in source ...
}
```

### disable_profiling_in_tc: patch NOP to skip-jump

```cpp
if (instr_map[i].ins_type == ProfilingIns && instr_map[i].xed_category == XED_CATEGORY_WIDENOP) {
  // compute disp to jump over the profiling block
  while (instr_map[i+j].ins_type == ProfilingIns) disp += instr_map[i+j++].size;
  disp += (instr_map[i].size - 5);
  xed_inst1(&enc_instr, dstate, XED_ICLASS_JMP, 64, xed_relbr(disp, 32));
  // encode into encoded_jmp_ins and overwrite the NOP stub
}
```

### fix_instructions_displacements: converging layout loop

```cpp
int fix_instructions_displacements()
{
  int size_diff = 0;
  do {
    size_diff = 0;
    for (unsigned i=0; i<num_of_instr_map_entries; i++) {
      instr_map[i].new_ins_addr += size_diff;
      int new_size = fix_rip_displacement(i);
      if (new_size > 0) { size_diff += (new_size - instr_map[i].size); instr_map[i].size = new_size; continue; }
      new_size = fix_direct_br_or_call_displacement(i);
      if (new_size > 0) { size_diff += (new_size - instr_map[i].size); instr_map[i].size = new_size; }
    }
  } while (size_diff != 0);
  return 0;
}
```

### fix_rip_displacement: recompute RIP-relative disp

```cpp
// decode current encoding
xed_decode(&xedd, (UINT8*)instr_map[e].encoded_ins, max_inst_len);
if (xed_decoded_inst_get_base_reg(&xedd,0) != XED_REG_RIP) return 0;
// absolute original target
unsigned orig_len = xed_decoded_inst_get_length(&xedd);
ADDRINT orig_target = instr_map[e].orig_ins_addr + disp + orig_len;
// compute new disp to target from new PC and re-encode
xed_encoder_request_init_from_decode(&xedd);
xed_encoder_request_set_memory_displacement(&xedd, new_disp, 4);
xed_encode(&xedd, (UINT8*)instr_map[e].encoded_ins, size, &new_size);
```

### fix_direct_br_or_call_displacement: rel32 or out-of-TC rewrite

```cpp
if (instr_map[e].orig_targ_addr == 0) return 0; // not direct
// decode, ensure category is CALL/COND_BR/UNCOND_BR
if (instr_map[e].targ_map_entry < 0) {
  // rewrite to reach original via RIP slot
  return fix_direct_br_call_to_orig_addr(e);
}
ADDRINT targ = instr_map[instr_map[e].targ_map_entry].new_ins_addr;
// compute new rel32 and re-encode
```

### commit_translated_rtns_to_tc: safety + probe replacement

```cpp
if (!RTN_IsSafeForProbedReplacement(rtn)) continue;
long long delta = (long long)instr_map[i].new_ins_addr - (long long)RTN_Address(rtn);
if ((unsigned long long)(delta<0?-delta:delta) > 0x7fffffffULL) {
  // skip: >2GB away
  continue;
}
AFUNPTR origFptr = RTN_ReplaceProbed(rtn, (AFUNPTR)instr_map[i].new_ins_addr);
```

### commit_translated_rtns_to_tc2: atomic probe write

```cpp
// encode a jmp from TC1 site to TC2 site into instr_map[i].encoded_ins
unsigned int olen = encode_jump_instr(instr_map[i].orig_ins_addr,
                                      instr_map[i].new_ins_addr,
                                      instr_map[i].encoded_ins);
// write last bytes first, then the first 4 bytes, atomically-visible patch
if (olen > 4)
  memcpy((char *)(instr_map[i].orig_ins_addr + 4),
         (char *)((ADDRINT)instr_map[i].encoded_ins + 4), olen - 4);
memcpy((char *)instr_map[i].orig_ins_addr, instr_map[i].encoded_ins, 4);
```

### plan_devirtualization_for_idx: heat and feasibility gates

```cpp
if (!KnobDevirtIndirects) return 0;
if (is_call && !KnobDevirtCallsToo) return 0;
if (KnobDevirtOnlyTerminators && bbl_map[bbl_id].terminating_ins_entry != idx) return 0;
UINT64 heat = bbl_map[bbl_id].counter;
if (heat < KnobIndirectMinCount) return 0;
ADDRINT hot = pick_hot_target_for_bbl(bbl_id, &hot_cnt);
if (hot_cnt * 100ULL < (UINT64)KnobIndirectHotPct * heat) return 0;
// ensure reg-indirect and scratch reg exists; map target by saved_orig_addr
```

### emit_guarded_devirt: guarded fast path + original slow path

```cpp
xed_reg_enum_t scr = XED_REG_INVALID; if (!choose_scratch_reg_for_idx(idx,&scr)) return 0;
const ADDRINT src_pc = e.new_ins_addr; const ADDRINT dst_pc = instr_map[e.devirt_target_entry].new_ins_addr;
char buf[128]; unsigned off=0,len=0;
encode_mov_imm64(scr,(UINT64)dst_pc, buf+off,&len); off+=len;      // mov scr, imm64
encode_cmp_rr(targReg,scr, buf+off,&len);           off+=len;      // cmp targReg, scr
unsigned jcc_len = get_jcc_rel32_len(XED_ICLASS_JNZ);
encode_jcc_rel32(src_pc+off, slow_pc, XED_ICLASS_JNZ, buf+off, &len); off+=len; // jnz slow
memcpy(buf+off, tmp_fast, fast_len); off+=fast_len;                 // fast: jmp/call rel32
memcpy(buf+off, e.encoded_ins, e.size); off+=e.size;                // slow: original indirect
memcpy(e.encoded_ins, buf, off); e.size = off;
```

## Deep dive: lifecycle and threading timeline

- Process start
  - Pin initializes; we register `ImageLoad`.
- ImageLoad (main exe)
  - Allocate structures and TC near code → build TC1 → chain → layout → fixups → copy → commit (probe) with safety.
- Execution begins (mostly from TC1, if committed)
  - Low-overhead BBL counters run; optional indirect-target histograms if enabled.
- Background thread (when `-create_tc2`)
  - Sleep `-prof_time` → disable TC1 profiling in-place → plan & materialize devirt → rebuild layout/fixups → copy TC2 → commit TC→TC2 probe once → “[TC2 SWITCH]”.
- Steady state
  - Execution runs from TC2; profiling is off; guarded devirt fast paths fire where hot targets match.

## Memory layout and address math

- TC/TC2 allocation
  - Best-effort mapping close to the original text to keep rel32 reaches valid for probes and direct branches.
- Probed replacement distance guard
  - We skip commits if |TC entry – RTN entry| > 0x7fffffff to avoid rel32 overflow in probe encodings.
  - Use `-prefer_near_text 1` (default) to increase chances of in-range mapping; add `-quiet_distance 1` to suppress per-site logs and rely on the commit summary.
- RIP-relative fixups
  - For any `[rip + disp32]`, recompute `disp32 = orig_abs - (new_pc + len)`; re-encode and allow size churn to converge in the outer loop.
- Direct branch/call fixups
  - If target inside TC: compute new rel32 to `target.new_ins_addr`.
  - Else: rewrite to `[rip+slot]` where `slot` points to the absolute original target address near TC.

## Helper contracts (inputs/outputs)

- encode_direct_relbr(pc, target_addr, is_call, out, out_olen)
  - In: source PC, absolute target, call vs jmp flag; Out: bytes in `out`, length in `out_olen`; Err: non-zero on failure.
- encode_jcc_rel32(pc, target_addr, jcc, out, out_olen)
  - In: source PC, absolute target, Jcc kind; Out: rel32 Jcc encoding.
- encode_mov_imm64(dst_r64, imm64, out, out_olen)
  - In: 64-bit GPR, immediate; Out: MOV r64, imm64.
- encode_cmp_rr(rA, rB, out, out_olen)
  - In: two regs; Out: CMP rA, rB.
- fix_rip_displacement(i) / fix_direct_br_or_call_displacement(i)
  - In: instr_map entry index; Out: 0 if unchanged, >0 new size, <0 on error.

Edge cases to expect:
- RIP mem without displacement width → skip; no-op.
- Conditional short-branch widen to rel32 → size increases; handled by the loop.
- Targets not in TC → out-of-TC rewrite via RIP slot.

## Logs: what they mean

- after memory allocation / identifying candidate routines / chaining / fixing displacements
  - Pipeline milestones for TC1 build.
- after write all new instructions to memory tc (or tc2)
  - Copy to memory is complete; `tc_size`/`tc2_size` set.
- after commit of translated routines from orig code to TC
  - Probed replacement for TC1 done.
- RTN_ReplaceProbed skipped due to >2GB distance
  - Proximity constraint hit; execution stays native for that RTN.
- [TC2 SWITCH] Committing jump from TC to TC2 …
  - The switch point; should appear exactly once.

## Performance tuning to hit ≤15% overhead

- Enable fast counters
  - Use `-use_killed_regs 1` to prefer killed-reg fast path (often RAX) and reduce save/restore.
- Avoid heavy profiling unless needed
  - Keep `-prof_indir 0` unless you need indirect-target histograms for devirt; this adds cost.
- Keep diagnostics off
  - Use `-verbose 0`, `-dump_* 0` for real runs; dumps slow things down.
- TC2 devirt thresholds
  - Start with `-indir_min_count` moderately high (e.g., 1000) and `-indir_hot_pct` 80–90 to avoid unstable sites.
- Commit staging
  - For bring-up: `-commit_limit 1..N`; for perf: `-commit_limit 0`.

## Before/After examples

- Direct call re-encode (pseudo-asm)
  - Before (orig): `call rel32 0x401234`
  - After (TC):   `call rel32 <tc_target>` (new displacement computed to `target.new_ins_addr`)

- RIP-relative load fixup
  - Before: `mov rax, [rip+0x1234]  ; targets 0x400000+...`
  - After:  `mov rax, [rip+new_disp] ; targets same absolute, recomputed from new_pc`

- Guarded devirt (indirect jmp)
  - Before: `jmp [r11]`
  - After:
    - `mov r10, imm64 <hot_target>`
    - `cmp r11, r10`
    - `jnz .slow`
    - `jmp rel32 <hot_target>`
    - `.slow: jmp [r11]`

## Slide-deck notes (cheatsheet)

- One-liner: Probe-mode TC1→profile→TC2 with guarded devirt; safe commits; ≤15% profiling overhead target.
- Safety: `RTN_IsSafeForProbedReplacement` + ±2GB guard + commit limit.
- Profiling: BBL counters at terminators; fast-path via killed reg; optional indirect target histograms.
- TC2: disable profiling, plan&materialize devirt pre-fixups, re-run fixups, copy, one-time switch.
- Devirt gates: heat, share, kind, feasibility; fast path is a Jcc + rel32 direct to the hot target.
