---
marp: true
theme: default
paginate: true
headingDivider: 2
---

# Probe-mode Pintool: TC1 → Profile → TC2

- Translation, profiling, and optimized switch with ≤15% overhead (excluding TC build)
- Safe probed commits, guarded devirtualization, rich diagnostics

Notes:
- Keep focus on low-overhead profiling, safety gates, and one-time TC2 switch.

---

## Goals & Requirements

- Build TC1 with minimal profiling; run app from TC1
- After profiling window, build TC2 and switch once
- ≤15% runtime overhead (excluding TC build time)
- Safety: RTN_IsSafeForProbedReplacement + ±2GB distance guard

Notes:
- Emphasize probe mode; no JIT trampolines.

---

## Architecture Overview

- ImageLoad: orchestrates TC1 pipeline
- TC1: translated code + low-overhead BBL counters
- Background thread: sleep → build TC2 → switch
- TC2: optional guarded devirtualization of hot indirect branches/calls

Notes:
- Show log markers to prove stages.

---

## Data Structures

- instr_map_t: one per instruction (orig/saved addr, new addr, bytes, size, links, devirt)
- bbl_map_t: per-BBL counters and optional indirect-target histogram
- jump_to_orig_addr_map: out-of-TC target slots for rel32 reachability

Notes:
- saved_orig_addr remains immutable identity.

---

## TC1 Pipeline (ImageLoad)

1) allocate_and_init_memory(img)
2) create_tc(img)
3) chain_all_direct_br_and_call_target_entries
4) set_initial_estimated_new_ins_addrs_in_tc
5) fix_instructions_displacements
6) copy_instrs_to_tc
7) commit_translated_rtns_to_tc (if allowed)

```cpp
VOID ImageLoad(IMG img, VOID *v) {
  allocate_and_init_memory(img);
  create_tc(img);
  chain_all_direct_br_and_call_target_entries(0, num_of_instr_map_entries);
  set_initial_estimated_new_ins_addrs_in_tc(tc);
  fix_instructions_displacements();
  copy_instrs_to_tc(tc);
  if (!KnobDoNotCommitTranslatedCode && !getenv("PIN_NO_TC_COMMIT"))
    commit_translated_rtns_to_tc();
}
```

Notes:
- Keep slides crisp; details later.

---

## Profiling in TC1

- BBL counters at terminators; fast path prefers a killed register (RAX)
- Optional: indirect-target histogram for indirect JMP/CALL (off by default)

```cpp
// add_profiling_instrs(...)
// Fast: use killed RAX → no saves
// Fallback: save/restore RAX; load/inc/store counter
```

Notes:
- Fast path helps keep ≤15%.

---

## Fixups & Layout

- RIP-relative: recompute disp32 to same absolute target from new PC
- Direct branches/calls: rel32 to TC target; otherwise rewrite via [rip+slot]
- Converging loop until sizes stabilize

```cpp
int fix_instructions_displacements(){
  int size_diff=0; do{
    size_diff=0;
    for(i){ new_addr += size_diff;
      s=fix_rip_displacement(i); if(s>0){size_diff+=s-size; size=s; continue;}
      s=fix_direct_br_or_call_displacement(i); if(s>0){size_diff+=s-size; size=s;}
    }
  }while(size_diff!=0);
}
```

Notes:
- Two-pass per instruction via XED encode.

---

## Safe Commit (TC1)

- Check `RTN_IsSafeForProbedReplacement`
- ±2GB distance guard; skip far routines
- Optional `-commit_limit` to stage rollout

```cpp
long long d = (long long)new - (long long)RTN_Address(rtn);
if ((unsigned long long)(d<0?-d:d) > 0x7fffffffULL) skip;
RTN_ReplaceProbed(rtn, (AFUNPTR)new);
```

Notes:
- Safety first; native fallback when far.

---

## TC2 Thread & Switch

- Sleep `-prof_time`; disable TC1 profiling in-place
- Plan devirt; re-chain, layout, fixups; copy to TC2
- One-time probed jump from TC1 site to TC2 entry

```cpp
disable_profiling_in_tc(instr_map, n);
if (KnobDevirtIndirects) for (i) plan_devirtualization_for_idx(i,bbl);
chain_all_direct_br_and_call_target_entries(0,n);
fix_instructions_displacements(); copy_instrs_to_tc(tc2);
commit_translated_rtns_to_tc2(); // "[TC2 SWITCH]"
```

Notes:
- Exactly one switch log.

---

## Guarded Devirtualization (TC2)

- For hot, predictable indirect JMP/CALL
- Emit MOV/CMP/JNZ + direct rel32 fast path + original slow path

```cpp
mov scr, imm64 <hot>
cmp targReg, scr
jnz slow
  jmp/call rel32 <hot>
slow: original indirect
```

Notes:
- Gated by heat/share/kind & feasibility.

---

## Knobs (selected)

- -create_tc2: enable TC2 thread & switch
- -use_killed_regs: fast profiling path
- -prof_indir: collect indirect-target histograms
- -devirt_indir, -devirt_calls_too, -devirt_only_terminators
- -indir_hot_pct, -indir_min_count: devirt thresholds
- -commit_limit, -no_tc_commit (or PIN_NO_TC_COMMIT)

Notes:
- Defaults tuned for safety; enable selectively.

---

## Performance to ≤15%

- Use fast counters (`-use_killed_regs 1`)
- Avoid `-prof_indir` unless needed
- Keep dumps/logging off for perf runs
- Conservative devirt thresholds (e.g., min_count=1000, hot_pct=80–90)

Notes:
- Measure with and without TC build time.

---

## Logs & Troubleshooting

- Milestones: after allocation/chaining/fixups/copy/commit
- Skips: “>2GB distance” → routine stays native
- Switch: “[TC2 SWITCH] …” appears once
- Use `-dump_tc`, `-dump_tc2`, `-dump_prof` to verify

Notes:
- Start with PIN_NO_TC_COMMIT=1 for safe validation.

---

## Code Pointers

- ImageLoad: end-to-end TC1 build & commit
- Profiling: `add_profiling_instrs`, `disable_profiling_in_tc`
- Fixups: `fix_rip_displacement`, `fix_direct_br_or_call_displacement`, loop
- Devirt: `plan_devirtualization_for_idx`, `emit_guarded_devirt`
- Commit: `commit_translated_rtns_to_tc`, `commit_translated_rtns_to_tc2`

Notes:
- See docs/CODE_OVERVIEW.md for deep dive.

---

## Demo (optional)

- Run with safe flags:
  - PIN_NO_TC_COMMIT=1
  - -dump_tc 1 -dump_prof 1 -use_killed_regs 1
- Then enable commit & TC2:
  - -create_tc2 1 -prof_time 2 -devirt_indir 1

Notes:
- Adjust to your environment.

---

## Q&A

- What is ImageLoad? Pin callback per loaded image; orchestrates TC1.
- How do we ensure safety? Probe-safe + ±2GB guard + commit limit.
- How does devirt pick targets? Per-BBL histogram share & count gates.
- How to prove switch? One-time “[TC2 SWITCH]” log.

Notes:
- Keep answers short and point to logs.
