# Project: Probe-Mode Translation Cache with TC2 and Guarded Devirtualization

This Pin tool translates hot routines into a Translation Cache (TC) in Probe mode with low-overhead BBL profiling (TC1). After a short profiling period, it builds a second cache (TC2), optionally applies guarded devirtualization of hot indirect branches, and switches execution from TC to TC2 with a one-time probe jump.

Key goals
- Low overhead: ≤15% over native (excluding TC creation time) using lightweight counters and killed-register fast paths.
- Robust TC2 switching: atomic two-stage patch and single “[TC2 SWITCH] …” log when committing.
- Safer commits: distance guard for probed replacement (>2GB skipped) and mapping hint to keep TC near the original code.
- Optional guarded devirtualization for hot indirect JMP/CALL sites in TC2.

## Build

Prerequisites
- Intel Pin 3.30+ (tested on pin-3.30-98830-g1d7b601b3-gcc-linux)
- GCC/Clang for Linux; MSVC for Windows

Linux (recommended)
```bash
make project.test
```

Windows (x64)
- Build into `obj-intel64/project.dll` using the Pin Windows samples makefiles or your IDE. Adjust include/lib paths to Pin’s SDK.

Note about toolchain flag
- If your GCC doesn’t recognize `-Wno-dangling-pointer`, remove/guard it in Pin’s config makefiles (e.g., source/tools/Config/makefile.default.rules) or filter it out.

## Quick start

Sanity: Build TC without committing (baseline correctness)
```bash
PIN_NO_TC_COMMIT=1 $PIN_ROOT/pin -t obj-intel64/project.so -- ./cc1 expr.i
```

Commit a small batch of routines to TC (isolate stability)
```bash
$PIN_ROOT/pin -t obj-intel64/project.so -no_tc_commit 0 -commit_limit 1 -- ./cc1 expr.i
```

Enable TC2 with guarded devirtualization
```bash
$PIN_ROOT/pin -t obj-intel64/project.so \
  -no_tc_commit 0 -create_tc2 1 -prof_time 4 \
  -devirt_indir 1 -devirt_only_terminators 1 \
  -- ./cc1 expr.i
```

Windows (PowerShell)
```powershell
$env:PIN_NO_TC_COMMIT = "1"
& "$env:PIN_ROOT\pin.exe" -t ".\obj-intel64\project.dll" -- "C:\path\to\app.exe" "args"
Remove-Item Env:PIN_NO_TC_COMMIT -ErrorAction SilentlyContinue
& "$env:PIN_ROOT\pin.exe" -t ".\obj-intel64\project.dll" -no_tc_commit 0 -create_tc2 1 -prof_time 4 -devirt_indir 1 -devirt_only_terminators 1 -- "C:\path\to\app.exe" "args"
```

What to expect
- TC build: “after commit of translated routines from orig code to TC”
- TC2 switch: one-time “[TC2 SWITCH] Committing jump from TC to TC2 …”
- Distance guard: “RTN_ReplaceProbed skipped due to >2GB distance …” (safe to ignore)

## Knobs (tool options)

Core
- -no_tc_commit [0|1]: Do not commit translated code (default 1). Set to 0 to commit.
- -create_tc2 [0|1]: Build TC2 after profiling window and commit TC→TC2 jump.
- -prof_time <secs>: Seconds to collect BBL counters (default 2).
- -commit_limit <N>: Max number of routines to commit to TC/TC2 (0 = all). Helps staging/bisecting.
- -quiet_distance [0|1]: Suppress per-routine “>2GB distance” lines; a single commit summary is printed (default 0).
- -prefer_near_text [0|1]: Hint allocator to place TC near original .text to reduce distance skips (default 1).

Devirtualization
- -devirt_indir [0|1]: Enable guarded devirtualization for hot indirect branches in TC2.
- -devirt_only_terminators [0|1]: Only at BBL-terminating indirects (default 1).
- -devirt_calls_too [0|1]: Consider indirect CALL sites as well (default 0).
- -indir_hot_pct <0..100>: Hotness threshold percentage for target selection (default 80).
- -indir_min_count <N>: Minimum executions to qualify (default 100).

Profiling & debug
- -use_killed_regs [0|1]: Use killed-register fast path for counters (default 1).
- -prof_indir [0|1]: Profile indirect targets in TC1 (default 0; costs overhead).
- -dump_tc, -dump_tc2, -dump_orig_code, -dump_prof: Verbose dumps for debugging.
- -probe_back_jumps [0|1]: Probe prior to backward jumps and at routine prologs (TC→TC2 helpers).
- -no_code_reorder [0|1]: Do not reorder code in TC2.

For a complete list, run: `$PIN_ROOT/pin -t obj-intel64/project.so -h`

## How it works (high level)
- TC1: Decode, analyze, chain, fix displacements, and copy instructions into RWX TC; insert minimal BBL counters using RAX fast path when safe.
- Commit to TC: Probed replacement per routine when safe; guarded by ±2GB distance check.
- TC2: After `-prof_time`, disable TC counters; plan and materialize guarded devirtualization stubs before fixups/copy; copy to TC2; atomically patch a near jump in TC head to TC2 head; log “[TC2 SWITCH] …” once.

## Performance methodology
- Measure runtime with and without the tool; subtract “create_tc took: …” time to exclude creation cost.
- Start with `-use_killed_regs 1 -prof_indir 0 -devirt_indir 1 -devirt_only_terminators 1`.
- Tune `-indir_hot_pct` and `-indir_min_count` for your workload.

## Troubleshooting
See docs/TROUBLESHOOTING.md for details. Common items:
- Many “RTN_ReplaceProbed failed”: prolog not safe or too far; try `-commit_limit` and keep going.
- Crash after commit: re-run with `PIN_NO_TC_COMMIT=1`; then enable `-no_tc_commit 0 -commit_limit 1`; disable `-use_killed_regs` if needed.
- `-commit_limit` unknown: rebuild the tool to include the new knob.
- Too many “>2GB distance” lines: add `-quiet_distance 1`. To improve reachability, keep `-prefer_near_text 1` (default) or try reducing input size so TC is smaller.

---

Maintained files
- `src/project.cpp` — main tool logic and knobs.
- `README.md` — this document.
- `docs/USAGE.md` — more examples and recipes.
- `docs/TROUBLESHOOTING.md` — common issues and fixes.
